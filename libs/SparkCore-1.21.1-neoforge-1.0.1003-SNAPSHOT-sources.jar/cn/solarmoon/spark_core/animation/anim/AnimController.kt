package cn.solarmoon.spark_core.animation.anim

import cn.solarmoon.spark_core.animation.IAnimatable
import cn.solarmoon.spark_core.animation.anim.origin.OAnimationSet
import cn.solarmoon.spark_core.animation.state.origin.OAnimStateMachineSet
import cn.solarmoon.spark_core.util.minus
import cn.solarmoon.spark_core.util.plus
import cn.solarmoon.spark_core.util.toEuler
import cn.solarmoon.spark_core.util.toVec3
import net.minecraft.world.phys.Vec3
import org.joml.Quaterniond
import org.joml.Vector3f
import kotlin.collections.component1
import kotlin.collections.component2

class AnimController(
    val animatable: IAnimatable<*>
) {

    val originAnimations get() = OAnimationSet.getOrEmpty(animatable.modelController.model?.index)
    val originStateMachines get() = OAnimStateMachineSet.getOrEmpty(animatable.modelController.model?.index?.location)

    val layers = mutableMapOf<Int, AnimLayer>()

    val stateMachines by lazy { originStateMachines.animationControllers.mapValues { it.value.build(animatable) } }

    var speedChangeTime = 0
        private set
    var overallSpeed = 1.0f
        private set

    val isPlayingAnim get() = layers.values.any { it.isPlaying }

    /**
     * 在指定时间内改变动画整体速度，时间结束后复原
     */
    fun changeSpeed(time: Int, speed: Float) {
        overallSpeed = speed
        speedChangeTime = time
    }

    fun playAnimation(anim: AnimInstance) {
        layers.getOrPut(anim.group) { AnimLayer() }.animations.add(anim)
    }

    fun stopAnimation(group: Int) {
        layers[group]?.animations?.forEach { it.exit() }
    }

    fun stopAllAnimation() {
        layers.values.forEach {
            it.animations.forEach { it.exit() }
        }
    }

    fun blendBone(boneName: String): KeyAnimData {
        val pos = Vector3f()
        val rot = Quaterniond()
        val scale = Vector3f(1f)
        layers.entries.sortedBy { it.key }.forEach { (_, layer) ->
            if (!layer.isPlaying) return@forEach
            val boneTransform = layer.blendBone(boneName)
            val weight = layer.getBoneWeight(boneName).toDouble()
            if (weight == 0.0) return@forEach // 简化计算
            when(layer.blendMode) {
                BlendMode.OVERRIDE -> {
                    pos.lerp(boneTransform.position.toVector3f(), weight.toFloat())
                    rot.slerp(Quaterniond().rotateZYX(boneTransform.rotation.z, boneTransform.rotation.y, boneTransform.rotation.x), weight)
                    scale.lerp(boneTransform.scale.toVector3f(), weight.toFloat())
                }
                BlendMode.ADDITIVE -> {
                    pos.add(boneTransform.position.toVector3f())
                    rot.mul(Quaterniond().rotateZYX(boneTransform.rotation.z, boneTransform.rotation.y, boneTransform.rotation.x))
                    // 最终缩放 = 下层缩放 × [1 + 权重 × (Additive缩放 - 1)]
                    scale.mul((Vec3(1.0, 1.0, 1.0) + (boneTransform.scale - Vec3(1.0, 1.0, 1.0)).multiply(Vec3(weight, weight, weight))).toVector3f())
                }
            }
        }
        return KeyAnimData(pos.toVec3(), rot.toEuler().toVec3(), scale.toVec3())
    }

    fun physTick() {
        layers.forEach { (_, layer) -> layer.physicsTick(overallSpeed) }

        animatable.modelController.model?.let { model ->
            model.origin.bones.forEach { (boneName, bone) ->
                val bonePose = model.pose.getBonePoseOrCreateEmpty(boneName)
                bonePose.updateInternal(blendBone(boneName))
            }
        }

        if (speedChangeTime > 0) speedChangeTime--
        else overallSpeed = 1.0f
    }

    fun tick() {
        animatable.modelController.model?.let { model ->
            model.origin.bones.forEach {
                model.pose.getBonePoseOrCreateEmpty(it.key).setChanged()
            }
        }

        layers.forEach { (_, layer) -> layer.tick() }

        stateMachines.values.forEach { it.tick() }
    }

}