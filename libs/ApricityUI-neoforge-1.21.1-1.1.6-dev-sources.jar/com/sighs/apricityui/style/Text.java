package com.sighs.apricityui.style;

import com.sighs.apricityui.element.AbstractText;
import com.sighs.apricityui.init.Element;
import com.sighs.apricityui.init.Style;
import com.sighs.apricityui.instance.Client;
import com.sighs.apricityui.resource.Font;

import java.awt.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class Text {
    private static final Canvas METRICS_CANVAS = new Canvas();
    private static final int LINE_WIDTH_CACHE_LIMIT = 2048;
    private static final Map<LineMeasureKey, Double> LINE_WIDTH_CACHE = Collections.synchronizedMap(new LinkedHashMap<>(64, 0.75f, true) {
        @Override
        protected boolean removeEldestEntry(Map.Entry<LineMeasureKey, Double> eldest) {
            return size() > LINE_WIDTH_CACHE_LIMIT;
        }
    });
    private String cachedKey = null;
    private int cachedKeyHash = 0;
    public double fontSize = -1;
    public int fontWeight = -1;
    public boolean oblique = false;
    public double strokeWidth = 0;
    public Color strokeColor = null;
    public Color color = null;
    public String fontFamily = "unset";
    public String content = "";
    public double lineHeight = -1;
    public String direction = "ltr";
    public String textAlign = "start";
    public String verticalAlign = "top";
    public String whiteSpace = "normal";
    public double textIndent = 0;
    public double letterSpacing = 0;
    public Size size = null;

    public static double getFontSize(Element element) {
        double fontSize = 16;
        for (Element e : element.getRoute()) {
            String f = e.getComputedStyle().fontSize;
            if (!f.equals("unset")) {
                Double parsed = Size.parseNumber(f);
                if (parsed != null) fontSize = parsed;
                break;
            }
        }
        return fontSize / 16d * 9;
    }

    public static String getFontFamily(Element element) {
        String fontFamily = "unset";
        for (Element e : element.getRoute()) {
            String f = e.getComputedStyle().fontFamily;
            if (!f.equals("unset")) {
                fontFamily = f;
                break;
            }
        }
        return fontFamily;
    }

    public static int getFontWeight(Element element) {
        int fontWeight = 400;
        for (Element e : element.getRoute()) {
            String f = e.getComputedStyle().fontWeight;
            if (!f.equals("unset")) {
                fontWeight = parseFontWeight(f);
                break;
            }
        }
        return fontWeight;
    }

    public static boolean isOblique(Element element) {
        for (Element e : element.getRoute()) {
            String f = e.getComputedStyle().fontStyle;
            if (!f.equals("unset")) {
                return isObliqueValue(f);
            }
        }
        return false;
    }

    public static int parseFontWeight(String raw) {
        if (raw == null || raw.isBlank()) return 400;
        String value = raw.trim().toLowerCase(Locale.ROOT);
        if (value.equals("unset") || value.equals("normal")) return 400;
        if (value.equals("bold") || value.equals("bolder")) return 700;
        if (value.equals("lighter")) return 300;
        try {
            int parsed = Integer.parseInt(value);
            if (parsed < 1) return 1;
            return Math.min(parsed, 1000);
        } catch (NumberFormatException ignored) {
        }
        return 400;
    }

    public static boolean isObliqueValue(String raw) {
        if (raw == null || raw.isBlank()) return false;
        String value = raw.trim().toLowerCase(Locale.ROOT);
        return value.equals("oblique");
    }

    public static Style.TextStroke parseTextStroke(String raw) {
        if (raw == null || raw.isBlank()) return Style.TextStroke.NONE;
        String value = raw.trim();
        String lower = value.toLowerCase(Locale.ROOT);
        if (lower.equals("unset") || lower.equals("none")) return Style.TextStroke.NONE;

        double width = 0;
        String colorPart = value;

        int pxIndex = lower.indexOf("px");
        if (pxIndex > 0) {
            int start = pxIndex - 1;
            while (start >= 0 && Character.isDigit(lower.charAt(start))) start--;
            String number = lower.substring(start + 1, pxIndex).trim();
            Double parsed = Size.parseNumber(number);
            if (parsed != null) width = Math.max(0, parsed);
            colorPart = (value.substring(0, Math.max(0, start + 1)) + " " + value.substring(pxIndex + 2)).trim();
        }

        int color = Color.parse(colorPart.isBlank() ? "#000" : colorPart);
        if (width <= 0) return Style.TextStroke.NONE;
        return new Style.TextStroke(width, color);
    }

    public static Style.TextStroke getTextStroke(Element element) {
        for (Element e : element.getRoute()) {
            String s = e.getComputedStyle().textStroke;
            if (!s.equals("unset")) {
                return parseTextStroke(s);
            }
        }
        return Style.TextStroke.NONE;
    }

    public static String getTextDirection(Element element) {
        for (Element e : element.getRoute()) {
            String value = e.getComputedStyle().direction;
            if (!value.equals("unset")) return value.trim().toLowerCase(Locale.ROOT);
        }
        return "ltr";
    }

    public static String getTextAlign(Element element) {
        for (Element e : element.getRoute()) {
            String value = e.getComputedStyle().textAlign;
            if (!value.equals("unset")) return value.trim().toLowerCase(Locale.ROOT);
        }
        return "start";
    }

    public static String getVerticalAlign(Element element) {
        for (Element e : element.getRoute()) {
            String value = e.getComputedStyle().verticalAlign;
            if (!value.equals("unset")) return value.trim().toLowerCase(Locale.ROOT);
        }
        return "top";
    }

    public static String getWhiteSpace(Element element) {
        for (Element e : element.getRoute()) {
            String value = e.getComputedStyle().whiteSpace;
            if (!value.equals("unset")) return value.trim().toLowerCase(Locale.ROOT);
        }
        return "normal";
    }

    public static double getTextIndent(Element element) {
        for (Element e : element.getRoute()) {
            String value = e.getComputedStyle().textIndent;
            if (!value.equals("unset")) {
                Double indent = Size.parseNumber(value);
                return indent == null ? 0 : indent;
            }
        }
        return 0;
    }

    public static double getLetterSpacing(Element element) {
        for (Element e : element.getRoute()) {
            String value = e.getComputedStyle().letterSpacing;
            if (!value.equals("unset")) {
                String normalized = value.trim().toLowerCase(Locale.ROOT);
                if (normalized.equals("normal")) return 0;
                Double spacing = Size.parseNumber(value);
                return spacing == null ? 0 : spacing;
            }
        }
        return 0;
    }

    public static int getFontColor(Element element) {
        String styleColor = element.getComputedStyle().color;
        if (styleColor.equals("unset")) {
            Element parent = element.parentElement;
            while (parent != null) {
                String parentColor = parent.getComputedStyle().color;
                if (!parentColor.equals("unset")) {
                    styleColor = parentColor;
                    break;
                }
                parent = parent.parentElement;
            }
        }
        if (styleColor.equals("unset")) {
            styleColor = "#000";
        }
        return Color.parse(styleColor);
    }

    public static int getSelectionColor(Element element) {
        String selection = element.getComputedStyle().selectionColor;
        if (selection.equals("unset")) {
            Element parent = element.parentElement;
            while (parent != null) {
                String parentSelection = parent.getComputedStyle().selectionColor;
                if (!parentSelection.equals("unset")) {
                    selection = parentSelection;
                    break;
                }
                parent = parent.parentElement;
            }
        }
        if (selection.equals("unset")) {
            selection = "#0078D7";
        }
        return Color.parse(selection);
    }

    public static Text of(Element element) {
        Text cache = element.getRenderer().text.get();
        if (cache != null) return cache;
        Text text = new Text();
        text.content = resolveElementTextContent(element);
        if (element.tagName.equals("INPUT")) text.content = element.value;
        if (element.tagName.equals("TEXTAREA")) text.content = element.value;
        String lineHeight = null;
        boolean resolvedFontStyle = false;
        boolean resolvedTextStroke = false;
        boolean resolvedDirection = false;
        boolean resolvedTextAlign = false;
        boolean resolvedVerticalAlign = false;
        boolean resolvedWhiteSpace = false;
        boolean resolvedTextIndent = false;
        boolean resolvedLetterSpacing = false;
        for (Element e : element.getRoute()) {
            Style style = e.getComputedStyle();
            boolean shouldBreak = true;
            if (text.fontFamily.equals("unset")) {
                shouldBreak = false;
                if (!style.fontFamily.equals("unset")) text.fontFamily = style.fontFamily;
            }
            if (text.fontSize == -1) {
                shouldBreak = false;
                if (!style.fontSize.equals("unset")) {
                    Double parsed = Size.parseNumber(style.fontSize);
                    if (parsed != null) text.fontSize = parsed;
                }
            }
            if (text.fontWeight == -1) {
                shouldBreak = false;
                if (!style.fontWeight.equals("unset")) text.fontWeight = parseFontWeight(style.fontWeight);
            }
            if (!resolvedFontStyle) {
                shouldBreak = false;
                if (!style.fontStyle.equals("unset")) {
                    text.oblique = isObliqueValue(style.fontStyle);
                    resolvedFontStyle = true;
                }
            }
            if (!resolvedTextStroke) {
                shouldBreak = false;
                if (!style.textStroke.equals("unset")) {
                    Style.TextStroke stroke = parseTextStroke(style.textStroke);
                    text.strokeWidth = stroke.width();
                    text.strokeColor = new Color(stroke.color());
                    resolvedTextStroke = true;
                }
            }
            if (text.color == null) {
                shouldBreak = false;
                if (!style.color.equals("unset")) text.color = new Color(style.color);
            }
            if (text.lineHeight == -1) {
                shouldBreak = false;
                if (!style.lineHeight.equals("unset")) lineHeight = style.lineHeight;
            }
            if (!resolvedDirection) {
                shouldBreak = false;
                if (!style.direction.equals("unset")) {
                    text.direction = normalizeDirection(style.direction);
                    resolvedDirection = true;
                }
            }
            if (!resolvedTextAlign) {
                shouldBreak = false;
                if (!style.textAlign.equals("unset")) {
                    text.textAlign = normalizeTextAlign(style.textAlign);
                    resolvedTextAlign = true;
                }
            }
            if (!resolvedVerticalAlign) {
                shouldBreak = false;
                if (!style.verticalAlign.equals("unset")) {
                    text.verticalAlign = normalizeVerticalAlign(style.verticalAlign);
                    resolvedVerticalAlign = true;
                }
            }
            if (!resolvedWhiteSpace) {
                shouldBreak = false;
                if (!style.whiteSpace.equals("unset")) {
                    text.whiteSpace = normalizeWhiteSpace(style.whiteSpace);
                    resolvedWhiteSpace = true;
                }
            }
            if (!resolvedTextIndent) {
                shouldBreak = false;
                if (!style.textIndent.equals("unset")) {
                    Double indent = Size.parseNumber(style.textIndent);
                    text.textIndent = indent == null ? 0 : indent;
                    resolvedTextIndent = true;
                }
            }
            if (!resolvedLetterSpacing) {
                shouldBreak = false;
                if (!style.letterSpacing.equals("unset")) {
                    text.letterSpacing = parseLetterSpacing(style.letterSpacing);
                    resolvedLetterSpacing = true;
                }
            }
            if (shouldBreak) break;
        }
        if (text.fontSize == -1) text.fontSize = 16;
        text.fontSize = text.fontSize / 16d * 9;
        if (text.fontWeight == -1) text.fontWeight = 400;
        if (text.color == null) text.color = Color.BLACK;
        if (text.strokeColor == null) text.strokeColor = Color.BLACK;
        if (!resolvedWhiteSpace) {
            if (element.tagName.equals("PRE")) text.whiteSpace = "pre";
            else if (element.tagName.equals("TEXTAREA")) text.whiteSpace = "pre-wrap";
        }
        if (!(element instanceof AbstractText)) {
            text.content = normalizeWhiteSpaceContent(text.content, text.whiteSpace);
        }

        if (text.lineHeight == -1) text.lineHeight = calculateLineHeight(text.fontSize, lineHeight);
        WrappedText wrapped = wrap(element, text);
        text.size = new Size(wrapped.width(), wrapped.height(text.lineHeight));

        element.getRenderer().text.set(text);
        return text;
    }

    private static String resolveElementTextContent(Element element) {
        if (element == null) return "";
        if (element.childNodes.isEmpty()) return element.innerText == null ? "" : element.innerText;
        StringBuilder builder = new StringBuilder();
        for (com.sighs.apricityui.init.Node child : element.childNodes) {
            if (child instanceof com.sighs.apricityui.init.TextNode textNode) {
                builder.append(textNode.getTextContent());
            }
        }
        if (builder.isEmpty()) {
            return element.innerText == null ? "" : element.innerText;
        }
        return builder.toString();
    }

    public static double calculateLineHeight(double fontSize, String lh) {
        if (lh == null || lh.isEmpty() || lh.equals("normal") || lh.equals("unset")) {
            return fontSize + 2;
        }

        if (lh.endsWith("px")) {
            Double parsed = Size.parseNumber(lh);
            return parsed != null ? parsed : fontSize + 2;
        } else if (lh.endsWith("%")) {
            Double percent = Size.parseNumber(lh);
            if (percent == null) return fontSize + 2;
            return fontSize * (percent / 100.0);
        } else {
            try {
                double multiplier = Double.parseDouble(lh);
                return fontSize * multiplier;
            } catch (NumberFormatException e) {
                Double val = Size.parseNumber(lh);
                return val != null ? val : fontSize + 2;
            }
        }
    }

    public static double measureText(Element element, String content) {
        Text text = Text.of(element);
        text.content = content;
        return measureText(text);
    }

    public static double measureText(Text text) {
        if (text.content == null || text.content.isEmpty()) return 0;
        List<String> lines = splitLines(text.content);
        double maxLine = 0;
        for (String line : lines) {
            maxLine = Math.max(maxLine, measureLine(text, line));
        }
        return maxLine;
    }

    public static double measureLine(Text text, String line) {
        if (text == null) return 0;
        if (line == null || line.isEmpty()) return 0;
        LineMeasureKey cacheKey = new LineMeasureKey(
                text.fontSize,
                text.fontWeight,
                text.oblique,
                text.strokeWidth,
                text.letterSpacing,
                text.fontFamily,
                line
        );
        Double cached = LINE_WIDTH_CACHE.get(cacheKey);
        if (cached != null) return cached;

        double measured = measureLineUncached(text, line);
        LINE_WIDTH_CACHE.put(cacheKey, measured);
        return measured;
    }

    private static double measureLineUncached(Text text, String line) {
        if (text == null) return 0;
        if (line == null || line.isEmpty()) return 0;
        int glyphCount = line.codePointCount(0, line.length());
        double letterSpacingWidth = glyphCount > 1 ? text.letterSpacing * (glyphCount - 1) : 0;

        if (text.fontFamily.equals("unset")) {
            return Client.getDefaultFontWidth(line, text.isBold(), text.isOblique(), 0) * (text.fontSize / 9.0) + text.strokeWidth * 2.0 + letterSpacingWidth;
        }

        int fontStyle = java.awt.Font.PLAIN;
        if (text.isBold()) fontStyle |= java.awt.Font.BOLD;
        if (text.isOblique()) fontStyle |= java.awt.Font.ITALIC;
        java.util.List<Font.FontRun> runs = Font.planFontRuns(text.fontFamily, fontStyle, Font.getBaseFontSize(), line);
        if (runs.isEmpty()) return 0;
        int baseWidth = 0;
        for (Font.FontRun run : runs) {
            if (run == null || run.font() == null || run.text() == null || run.text().isEmpty()) continue;
            FontMetrics fm = METRICS_CANVAS.getFontMetrics(run.font());
            baseWidth += fm.stringWidth(run.text());
        }

        float currentSize = (float) text.fontSize;
        float scale = currentSize / Font.getBaseFontSize();

        return baseWidth * scale + text.strokeWidth * 2.0 + letterSpacingWidth;
    }

    public String toKey() {
        int h = 1;
        h = 31 * h + (int) Math.round(fontSize * 1000);
        h = 31 * h + fontWeight;
        h = 31 * h + (oblique ? 1 : 0);
        h = 31 * h + (int) Math.round(strokeWidth * 1000);
        h = 31 * h + (strokeColor == null ? 0 : strokeColor.getValue());
        h = 31 * h + (color == null ? 0 : color.getValue());
        h = 31 * h + (fontFamily == null ? 0 : fontFamily.hashCode());
        h = 31 * h + (content == null ? 0 : content.hashCode());
        h = 31 * h + (direction == null ? 0 : direction.hashCode());
        h = 31 * h + (textAlign == null ? 0 : textAlign.hashCode());
        h = 31 * h + (verticalAlign == null ? 0 : verticalAlign.hashCode());
        h = 31 * h + (whiteSpace == null ? 0 : whiteSpace.hashCode());
        h = 31 * h + (int) Math.round(textIndent * 1000);
        h = 31 * h + (int) Math.round(letterSpacing * 1000);
        if (cachedKey != null && cachedKeyHash == h) return cachedKey;

        StringBuilder sb = new StringBuilder(64);
        sb.append(fontSize).append('/')
                .append(fontWeight).append('/')
                .append(oblique).append('/')
                .append(strokeWidth).append('/')
                .append(strokeColor == null ? 0 : strokeColor.getValue()).append('/')
                .append(color == null ? 0 : color.getValue()).append('/')
                .append(fontFamily == null ? "" : fontFamily).append('/')
                .append(content == null ? "" : content).append('/')
                .append(direction == null ? "" : direction).append('/')
                .append(textAlign == null ? "" : textAlign).append('/')
                .append(verticalAlign == null ? "" : verticalAlign).append('/')
                .append(whiteSpace == null ? "" : whiteSpace).append('/')
                .append(textIndent).append('/')
                .append(letterSpacing);
        cachedKey = sb.toString();
        cachedKeyHash = h;
        return cachedKey;
    }

    public boolean isBold() {
        return fontWeight >= 600;
    }

    public boolean isOblique() {
        return oblique;
    }

    public boolean hasStroke() {
        return strokeWidth > 0;
    }

    public boolean isRtl() {
        return "rtl".equals(direction);
    }

    public static List<String> splitLines(String content) {
        return List.of((content == null ? "" : content).split("\n", -1));
    }

    public static WrappedText wrap(Element element) {
        return wrap(element, Text.of(element));
    }

    public static WrappedText wrap(Element element, Text text) {
        if (element == null || text == null) return wrap(text, 0);
        return wrapCachedInternal(element, text, resolveWrapWidth(element, text));
    }

    public record WrappedTextCache(int metricsHash, int contentHash, int contentLen, long wrapWidthBits, WrappedText wrapped) {
    }

    /**
     * 带 Element 级缓存的换行结果。
     * <p>
     * wrap 属于 CPU 重活（尤其是大段文本），且通常在多帧内稳定不变；因此缓存到 RenderElement 中，
     * 仅在文本内容/字体相关样式/可用宽度变化时失效。
     */
    public static WrappedText wrapCached(Element element, Text text) {
        if (element == null || text == null) return wrap(text, 0);
        double wrapWidth = resolveWrapWidth(element, text);
        return wrapCachedInternal(element, text, wrapWidth);
    }

    private static WrappedText wrapCachedInternal(Element element, Text text, double wrapWidth) {
        long wrapWidthBits = Double.doubleToLongBits(wrapWidth);
        int metricsHash = wrapMetricsHash(text);
        String content = text.content == null ? "" : text.content;
        int contentHash = content.hashCode();
        int contentLen = content.length();

        WrappedTextCache cache = element.getRenderer().wrappedText.get();
        if (cache != null
                && cache.wrapWidthBits == wrapWidthBits
                && cache.metricsHash == metricsHash
                && cache.contentHash == contentHash
                && cache.contentLen == contentLen) {
            return cache.wrapped;
        }

        WrappedText wrapped = wrap(text, wrapWidth);
        element.getRenderer().wrappedText.set(new WrappedTextCache(metricsHash, contentHash, contentLen, wrapWidthBits, wrapped));
        return wrapped;
    }

    private static int wrapMetricsHash(Text text) {
        if (text == null) return 0;
        int h = 1;
        h = 31 * h + (int) Math.round(text.fontSize * 1000);
        h = 31 * h + text.fontWeight;
        h = 31 * h + (text.oblique ? 1 : 0);
        h = 31 * h + (int) Math.round(text.strokeWidth * 1000);
        h = 31 * h + (text.fontFamily == null ? 0 : text.fontFamily.hashCode());
        h = 31 * h + (text.whiteSpace == null ? 0 : text.whiteSpace.hashCode());
        h = 31 * h + (text.direction == null ? 0 : text.direction.hashCode());
        h = 31 * h + (int) Math.round(text.textIndent * 1000);
        h = 31 * h + (int) Math.round(text.letterSpacing * 1000);
        h = 31 * h + (int) Math.round(text.lineHeight * 1000);
        return h;
    }

    public static WrappedText wrap(Text text, double wrapWidth) {
        String content = text == null || text.content == null ? "" : text.content;
        List<String> hardLines = splitLines(content);
        List<String> lines = new ArrayList<>();
        List<Integer> starts = new ArrayList<>();
        double maxWidth = 0;
        boolean allowsSoftWrap = allowsSoftWrap(text == null ? null : text.whiteSpace) && wrapWidth > 0;
        int cursor = 0;

        for (String hardLine : hardLines) {
            if (!allowsSoftWrap) {
                lines.add(hardLine);
                starts.add(cursor);
                maxWidth = Math.max(maxWidth, measureLine(text, hardLine));
            } else {
                wrapHardLine(text, hardLine, cursor, wrapWidth, lines, starts);
            }
            cursor += hardLine.length() + 1;
        }

        if (lines.isEmpty()) {
            lines.add("");
            starts.add(0);
        }
        for (int i = 0; i < lines.size(); i++) {
            maxWidth = Math.max(maxWidth, measureLine(text, lines.get(i)));
        }
        if (wrapWidth > 0 && allowsSoftWrap(text == null ? null : text.whiteSpace)) {
            maxWidth = Math.min(maxWidth, wrapWidth);
        }

        int[] startArray = new int[starts.size()];
        for (int i = 0; i < starts.size(); i++) startArray[i] = starts.get(i);
        return new WrappedText(lines, startArray, maxWidth);
    }

    private static void wrapHardLine(Text text, String hardLine, int baseIndex, double wrapWidth,
                                     List<String> lines, List<Integer> starts) {
        if (hardLine.isEmpty()) {
            lines.add("");
            starts.add(baseIndex);
            return;
        }

        int lineStart = 0;
        Map<Integer, Double> codePointWidthCache = new java.util.HashMap<>();
        while (lineStart < hardLine.length()) {
            double width = 0;
            int lineEnd = lineStart;
            int lastBreak = -1;
            boolean firstGlyph = true;

            while (lineEnd < hardLine.length()) {
                int codePoint = hardLine.codePointAt(lineEnd);
                int charCount = Character.charCount(codePoint);
                char c = hardLine.charAt(lineEnd);
                double charWidth = codePointWidthCache.computeIfAbsent(codePoint, key -> measureLine(text, new String(Character.toChars(key))));
                if (!firstGlyph && width + charWidth > wrapWidth) break;
                width += charWidth;
                if (isPreferredBreakChar(text == null ? null : text.whiteSpace, c)) {
                    lastBreak = lineEnd;
                }
                lineEnd += charCount;
                firstGlyph = false;
            }

            if (lineEnd >= hardLine.length()) {
                lines.add(hardLine.substring(lineStart));
                starts.add(baseIndex + lineStart);
                return;
            }

            if (lineEnd == lineStart) {
                lineEnd += Character.charCount(hardLine.codePointAt(lineStart));
            }

            if (lastBreak >= lineStart && consumesBreakChar(text == null ? null : text.whiteSpace, hardLine.charAt(lastBreak))) {
                lines.add(hardLine.substring(lineStart, lastBreak));
                starts.add(baseIndex + lineStart);
                lineStart = lastBreak + 1;
                continue;
            }

            int resolvedEnd = lastBreak >= lineStart ? lastBreak + 1 : lineEnd;
            lines.add(hardLine.substring(lineStart, resolvedEnd));
            starts.add(baseIndex + lineStart);
            lineStart = resolvedEnd;
        }

    }

    private static boolean isPreferredBreakChar(String whiteSpace, char c) {
        String value = whiteSpace == null ? "normal" : whiteSpace;
        if ("normal".equals(value) || "pre-line".equals(value)) return c == ' ';
        return c == ' ' || c == '\t';
    }

    private static boolean consumesBreakChar(String whiteSpace, char c) {
        String value = whiteSpace == null ? "normal" : whiteSpace;
        if ("normal".equals(value) || "pre-line".equals(value)) return c == ' ';
        return false;
    }

    public static boolean allowsSoftWrap(String whiteSpace) {
        String value = whiteSpace == null ? "normal" : whiteSpace;
        return switch (value) {
            case "normal", "pre-wrap", "pre-line", "break-spaces" -> true;
            default -> false;
        };
    }

    private static double resolveWrapWidth(Element element, Text text) {
        if (element == null || text == null || !allowsSoftWrap(text.whiteSpace)) return 0;
        Style style = element.getRawComputedStyle();
        Double explicitWidth = Size.parseNumber(style.width);
        Box box = Box.of(element);
        double resolved;
        if (explicitWidth != null) {
            resolved = Size.resolveLength(style.width, Size.getScaleWidth(element), explicitWidth);
            if (Box.BOX_SIZING_BORDER_BOX.equals(Box.normalizeBoxSizing(style.boxSizing))) {
                resolved -= box.getBorderHorizontal() + box.getPaddingHorizontal();
            }
        } else {
            String display = style.display == null ? "block" : style.display.trim().toLowerCase(Locale.ROOT);
            if ("inline".equals(display) || "inline-block".equals(display)) return 0;
            resolved = Size.getScaleWidth(element) - box.getBorderHorizontal() - box.getPaddingHorizontal();
        }
        if (Math.abs(text.textIndent) > 1e-4) {
            resolved -= Math.abs(text.textIndent);
        }
        return Math.max(0, resolved);
    }

    private static String normalizeDirection(String raw) {
        String value = raw == null ? "" : raw.trim().toLowerCase(Locale.ROOT);
        return "rtl".equals(value) ? "rtl" : "ltr";
    }

    private static String normalizeTextAlign(String raw) {
        String value = raw == null ? "" : raw.trim().toLowerCase(Locale.ROOT);
        return switch (value) {
            case "left", "right", "center", "justify", "start", "end" -> value;
            default -> "start";
        };
    }

    private static String normalizeVerticalAlign(String raw) {
        String value = raw == null ? "" : raw.trim().toLowerCase(Locale.ROOT);
        return switch (value) {
            case "top", "middle", "center", "bottom", "text-top", "text-bottom" -> value;
            default -> "top";
        };
    }

    private static String normalizeWhiteSpace(String raw) {
        String value = raw == null ? "" : raw.trim().toLowerCase(Locale.ROOT);
        return switch (value) {
            case "normal", "nowrap", "pre", "pre-wrap", "pre-line", "break-spaces" -> value;
            default -> "normal";
        };
    }

    private static double parseLetterSpacing(String raw) {
        if (raw == null || raw.isBlank()) return 0;
        String value = raw.trim().toLowerCase(Locale.ROOT);
        if (value.equals("normal") || value.equals("unset")) return 0;
        Double parsed = Size.parseNumber(raw);
        return parsed == null ? 0 : parsed;
    }

    public static String normalizeWhiteSpaceContent(String content, String whiteSpace) {
        if (content == null || content.isEmpty()) return "";
        String value = whiteSpace == null ? "normal" : whiteSpace;
        return switch (value) {
            case "pre", "pre-wrap", "break-spaces" -> content.replace("\r\n", "\n").replace('\r', '\n');
            case "pre-line" -> collapseSpacesPreserveNewlines(content);
            case "nowrap", "normal" -> collapseToSingleLine(content);
            default -> collapseToSingleLine(content);
        };
    }

    private static String collapseToSingleLine(String content) {
        String normalized = content.replace("\r\n", "\n").replace('\r', '\n');
        normalized = normalized.replace('\n', ' ');
        return normalized.replaceAll("[\\t\\x0B\\f ]+", " ").trim();
    }

    private static String collapseSpacesPreserveNewlines(String content) {
        String normalized = content.replace("\r\n", "\n").replace('\r', '\n');
        String[] lines = normalized.split("\n", -1);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < lines.length; i++) {
            if (i > 0) sb.append('\n');
            sb.append(lines[i].replaceAll("[\\t\\x0B\\f ]+", " ").trim());
        }
        return sb.toString();
    }

    private record LineMeasureKey(double fontSize, int fontWeight, boolean oblique, double strokeWidth,
                                  double letterSpacing, String fontFamily, String line) {
    }

    public record WrappedText(List<String> lines, int[] starts, double width) {
        public double height(double lineHeight) {
            return Math.max(lineHeight, lines.size() * lineHeight);
        }
    }
}
