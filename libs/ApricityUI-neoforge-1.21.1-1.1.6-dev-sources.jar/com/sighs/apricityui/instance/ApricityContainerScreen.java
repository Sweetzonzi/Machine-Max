package com.sighs.apricityui.instance;

import com.sighs.apricityui.init.Document;
import com.sighs.apricityui.init.Drawer;
import com.sighs.apricityui.init.Element;
import com.sighs.apricityui.init.Event;
import com.sighs.apricityui.instance.element.Container;
import com.sighs.apricityui.instance.element.MinecraftElement;
import com.sighs.apricityui.instance.element.Recipe;
import com.sighs.apricityui.instance.element.Slot;
import com.sighs.apricityui.mixin.accessor.AbstractContainerScreenAccessor;
import com.sighs.apricityui.mixin.accessor.SlotAccessor;
import com.sighs.apricityui.render.Base;
import com.sighs.apricityui.style.Cursor;
import com.sighs.apricityui.style.Position;
import com.sighs.apricityui.util.common.NormalizeUtil;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.NotNull;

import java.util.*;

public class ApricityContainerScreen extends AbstractContainerScreen<ApricityContainerMenu> {
    private static final String DEVTOOLS_PATH = "devtools/index.html";
    private static final int QUICK_CRAFT_GHOST_COLOR = -2130706433;
    private static final float ICON_SCALE_EPSILON = 0.0001F;
    private static final int OFFSCREEN_SLOT_POS = -10000;

    private Document linkedDocument;
    private final ArrayList<Slot> boundSlots = new ArrayList<>();
    private final ArrayList<Slot> unboundSlots = new ArrayList<>();
    private final HashMap<Slot, Integer> boundGlobalIndexByElement = new HashMap<>();
    private final HashMap<Slot, Container> boundContainerByElement = new HashMap<>();
    private final IdentityHashMap<net.minecraft.world.inventory.Slot, Slot> boundElementByMenuSlot = new IdentityHashMap<>();
    private boolean slotsBound = false;
    private boolean slotSyncDirty = true;
    private int lastKnownDomSlotCount = -1;
    private long lastBindGeneration = -1L;

    public ApricityContainerScreen(ApricityContainerMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
    }

    public ApricityContainerScreen(String path) {
        this(ApricityContainerMenu.createClientOnly(Minecraft.getInstance().player.getInventory(), path),
                Minecraft.getInstance().player.getInventory(),
                Component.literal("ApricityScreen"));
    }

    public Document getLinkedDocument() {
        return linkedDocument;
    }

    public int getGuiLeft() {
        return super.getGuiLeft();
    }

    public int getGuiTop() {
        return super.getGuiTop();
    }

    public int findSlotIndexAt(double mouseX, double mouseY) {
        for (int index = 0; index < menu.slots.size(); index++) {
            net.minecraft.world.inventory.Slot slot = menu.slots.get(index);
            if (!isSlotPointerInteractable(slot)) continue;
            int slotSize = resolveSlotSize(slot);
            if (isHovering(slot.x, slot.y, slotSize, slotSize, mouseX, mouseY)) {
                return index;
            }
        }
        return -1;
    }

    public boolean isSlotPointerInteractable(net.minecraft.world.inventory.Slot slot) {
        if (slot == null || !slot.isActive()) return false;
        if (!(slot instanceof ApricityContainerMenu.UiSlot uiSlot)) {
            return isBoundSlotPointerEnabledByCss(slot);
        }
        return !uiSlot.isUiHidden()
                && !uiSlot.isUiDisabled()
                && uiSlot.isUiAcceptPointer()
                && isBoundSlotPointerEnabledByCss(slot);
    }

    @Override
    protected void init() {
        imageWidth = width;
        imageHeight = height;
        super.init();

        // 窗口 resize 会重新调用 init()，需要先清理旧 Document 避免残留
        if (linkedDocument != null) {
            linkedDocument.remove();
            linkedDocument = null;
        }
        clearSlotBindings();

        linkedDocument = Document.create(menu.getTemplatePath());
        if (linkedDocument == null) return;

        bindSlotsFromDocument();
        syncAllSlotPositions(true);
    }

    @Override
    protected void renderBg(@NotNull GuiGraphics guiGraphics, float partialTick, int mouseX, int mouseY) {
        if (linkedDocument == null) return;

        Base.drawScreenDocument(guiGraphics.pose(), linkedDocument);
        Minecraft.getInstance().renderBuffers().bufferSource().endBatch();
        drawMenuSlotItems(guiGraphics);
        drawDisplaySlotItems(guiGraphics);
    }

    @Override
    protected void renderLabels(@NotNull GuiGraphics guiGraphics, int mouseX, int mouseY) {
        // 不绘制 Minecraft 默认标题；标题如有需要由模板普通 DOM 自行实现。
    }

    @Override
    public void render(@NotNull GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        if (linkedDocument != null) {
            if (shouldRebindSlotsFromDom()) {
                bindSlotsFromDocument();
                syncAllSlotPositions(true);
            } else {
                syncAllSlotPositions(false);
            }
        }

        super.render(guiGraphics, mouseX, mouseY, partialTick);
        drawSlotHoverTooltipByElement(guiGraphics, mouseX, mouseY);
        drawDevToolsOverlay(guiGraphics);
        Cursor.drawPseudoCursor(guiGraphics);
    }

    private void bindSlotsFromDocument() {
        if (linkedDocument == null) return;

        boundSlots.clear();
        unboundSlots.clear();
        boundGlobalIndexByElement.clear();
        boundContainerByElement.clear();
        boundElementByMenuSlot.clear();

        LinkedHashMap<String, Container> containerById = resolveTopLevelContainerMapping();
        IdentityHashMap<Container, String> containerIdByElement = new IdentityHashMap<>();
        for (Map.Entry<String, Container> entry : containerById.entrySet()) {
            containerIdByElement.put(entry.getValue(), entry.getKey());
        }

        HashMap<String, Integer> nextImplicitLocalIndex = new HashMap<>();
        HashSet<Integer> usedGlobalSlots = new HashSet<>();

        List<Element> snapshot = new ArrayList<>(linkedDocument.getElements());
        for (Element element : snapshot) {
            if (!(element instanceof Slot slot)) continue;
            if (slot.findAncestor(Recipe.class) != null) {
                slot.bindMcSlot(null);
                unboundSlots.add(slot);
                continue;
            }

            Container ownerContainer = slot.findAncestor(Container.class);
            if (ownerContainer == null) {
                slot.bindMcSlot(null);
                unboundSlots.add(slot);
                continue;
            }
            String containerId = containerIdByElement.get(ownerContainer);
            if (containerId == null || containerId.isBlank()) {
                slot.bindMcSlot(null);
                unboundSlots.add(slot);
                continue;
            }

            int localSlotIndex = slot.getSlotIndex();
            if (localSlotIndex < 0) {
                localSlotIndex = nextImplicitLocalIndex.getOrDefault(containerId, 0);
                slot.setAttribute("slot-index", String.valueOf(localSlotIndex));
            }
            int nextLocalSlotIndex = Math.max(nextImplicitLocalIndex.getOrDefault(containerId, 0), localSlotIndex + 1);
            nextImplicitLocalIndex.put(containerId, nextLocalSlotIndex);

            Integer globalSlotIndex = menu.resolveGlobalSlotIndex(containerId, localSlotIndex);
            if (globalSlotIndex == null
                    || globalSlotIndex < 0
                    || globalSlotIndex >= menu.slots.size()
                    || !usedGlobalSlots.add(globalSlotIndex)) {
                slot.bindMcSlot(null);
                unboundSlots.add(slot);
                continue;
            }

            net.minecraft.world.inventory.Slot menuSlot = menu.slots.get(globalSlotIndex);
            slot.bindMcSlot(menuSlot);
            boundSlots.add(slot);
            boundGlobalIndexByElement.put(slot, globalSlotIndex);
            boundContainerByElement.put(slot, ownerContainer);
            boundElementByMenuSlot.put(menuSlot, slot);
        }
        slotsBound = true;
        slotSyncDirty = true;
        lastKnownDomSlotCount = countDomSlotElements();
        lastBindGeneration = linkedDocument.getRefreshGeneration();
    }

    private boolean shouldRebindSlotsFromDom() {
        if (!slotsBound) return true;
        if (linkedDocument == null) return false;
        if (linkedDocument.getRefreshGeneration() != lastBindGeneration) return true;
        int currentSlotCount = countDomSlotElements();
        if (currentSlotCount < 0) return false;
        if (currentSlotCount != lastKnownDomSlotCount) return true;
        return currentSlotCount != (boundSlots.size() + unboundSlots.size());
    }

    private int countDomSlotElements() {
        if (linkedDocument == null) return -1;
        int count = 0;
        for (Element element : linkedDocument.getElements()) {
            if (element instanceof Slot) count++;
        }
        return count;
    }

    private LinkedHashMap<String, Container> resolveTopLevelContainerMapping() {
        LinkedHashMap<String, Container> result = new LinkedHashMap<>();
        if (linkedDocument == null) return result;

        LinkedHashMap<String, Container> domContainerById = new LinkedHashMap<>();
        for (Element element : linkedDocument.getElements()) {
            if (!(element instanceof Container container)) continue;
            String normalizedId = NormalizeUtil.normalizeContainerId(container.getAttribute("id"));
            if (normalizedId == null) continue;
            domContainerById.putIfAbsent(normalizedId, container);
        }

        List<String> containerIds = menu.getLayoutSpec().containerIds();
        for (String containerId : containerIds) {
            String normalizedId = NormalizeUtil.normalizeContainerId(containerId);
            if (normalizedId == null) continue;
            Container matched = domContainerById.get(normalizedId);
            if (matched == null) continue;
            result.put(normalizedId, matched);
        }
        return result;
    }

    /**
     * 玩家容器头部（第一个 slot 之前的非 slot 直接子节点）强制跨满 9 列，
     * 避免标题占用首格导致首行槽位只剩 8 列。
     */
    private boolean shouldSyncSlotPositions(boolean force) {
        if (force || slotSyncDirty) return true;
        return linkedDocument != null && !linkedDocument.getDirtyElements().isEmpty();
    }

    private void syncAllSlotPositions(boolean force) {
        if (linkedDocument == null) return;
        if (!shouldSyncSlotPositions(force)) return;

        Drawer.flushUpdates(linkedDocument);

        for (net.minecraft.world.inventory.Slot slot : menu.slots) {
            setMenuSlotPosition(slot, OFFSCREEN_SLOT_POS, OFFSCREEN_SLOT_POS);
            if (slot instanceof ApricityContainerMenu.UiSlot uiSlot) {
                uiSlot.setUiHidden(true);
            }
        }

        LinkedHashMap<Container, ArrayList<Map.Entry<Slot, Integer>>> groupedEntries = new LinkedHashMap<>();
        for (Map.Entry<Slot, Integer> entry : boundGlobalIndexByElement.entrySet()) {
            Slot boundElement = entry.getKey();
            if (boundElement == null) continue;
            Container ownerContainer = boundContainerByElement.get(boundElement);
            if (ownerContainer == null) {
                ownerContainer = boundElement.findAncestor(Container.class);
                if (ownerContainer != null) {
                    boundContainerByElement.put(boundElement, ownerContainer);
                }
            }
            if (ownerContainer == null) continue;
            groupedEntries.computeIfAbsent(ownerContainer, ignored -> new ArrayList<>()).add(entry);
        }

        for (ArrayList<Map.Entry<Slot, Integer>> entries : groupedEntries.values()) {
            for (Map.Entry<Slot, Integer> entry : entries) {
                Slot boundElement = entry.getKey();
                int globalSlotIndex = entry.getValue();
                if (boundElement == null) continue;
                if (globalSlotIndex < 0 || globalSlotIndex >= menu.slots.size()) continue;

                net.minecraft.world.inventory.Slot menuSlot = menu.slots.get(globalSlotIndex);
                boolean hidden = !boundElement.isVisible || "none".equals(boundElement.getComputedStyle().display);

                int slotSize = resolveBoundSlotPixelSize(boundElement, menuSlot);
                if (hidden) {
                    setMenuSlotPosition(menuSlot, OFFSCREEN_SLOT_POS, OFFSCREEN_SLOT_POS);
                } else {
                    Position screenPos = Position.of(boundElement);
                    int screenX = (int) Math.round(screenPos.x);
                    int screenY = (int) Math.round(screenPos.y);
                    setMenuSlotPosition(menuSlot, screenX - leftPos, screenY - topPos);
                }

                if (menuSlot instanceof ApricityContainerMenu.UiSlot uiSlot) {
                    uiSlot.setUiSlotSize(slotSize);
                    uiSlot.setUiHidden(hidden);
                }
            }
        }

        slotSyncDirty = false;
    }

    private int resolveBoundSlotPixelSize(Slot boundElement, net.minecraft.world.inventory.Slot menuSlot) {
        if (boundElement != null) {
            int fromElement = boundElement.resolveSlotSizeHint(16);
            if (fromElement > 0) return fromElement;
        }

        if (menuSlot instanceof ApricityContainerMenu.UiSlot uiSlot) {
            return Math.max(1, uiSlot.getUiSlotSize());
        }

        Container ownerContainer = boundContainerByElement.get(boundElement);
        if (ownerContainer == null) {
            if (boundElement != null) {
                ownerContainer = boundElement.findAncestor(Container.class);
            }
            if (ownerContainer != null) {
                boundContainerByElement.put(boundElement, ownerContainer);
            }
        }
        if (ownerContainer != null) {
            return Math.max(1, ownerContainer.resolveSlotSizePx(16));
        }
        return 16;
    }

    private boolean isBoundSlotPointerEnabledByCss(net.minecraft.world.inventory.Slot menuSlot) {
        Slot boundElement = boundElementByMenuSlot.get(menuSlot);
        if (boundElement == null) return true;
        if (boundElement.findAncestor(Recipe.class) != null) return false;
        if (!boundElement.isVisible) return false;
        if ("none".equals(boundElement.getComputedStyle().display)) return false;
        return boundElement.shouldAcceptPointer();
    }

    private void drawMenuSlotItems(GuiGraphics guiGraphics) {
        AbstractContainerScreenAccessor accessor = (AbstractContainerScreenAccessor) this;
        net.minecraft.world.inventory.Slot clicked = accessor.apricityui$getClickedSlot();
        ItemStack draggingItem = accessor.apricityui$getDraggingItem();
        boolean splitting = accessor.apricityui$isSplittingStack();
        Set<net.minecraft.world.inventory.Slot> quickCraftSlots = accessor.apricityui$getQuickCraftSlots();
        boolean quickCrafting = accessor.apricityui$isQuickCrafting();
        int quickCraftingType = accessor.apricityui$getQuickCraftingType();
        ItemStack carried = menu.getCarried();

        int quickCraftBasePlaceCount = 0;
        if (quickCrafting && !carried.isEmpty() && quickCraftSlots != null && quickCraftSlots.size() > 1) {
            quickCraftBasePlaceCount = AbstractContainerMenu.getQuickCraftPlaceCount(quickCraftSlots, quickCraftingType, carried);
        }

        for (net.minecraft.world.inventory.Slot slot : menu.slots) {
            SlotVisual visual = resolveSlotVisual(slot);
            int globalSlotIndex = menu.slots.indexOf(slot);
            if (visual.hidden || visual.disabled || !visual.renderItem) continue;
            if (slot == null || !slot.isActive()) continue;

            ItemStack renderStack = slot.getItem();
            String overlayText = null;
            boolean drawQuickCraftGhost = false;

            if (slot == clicked && !draggingItem.isEmpty() && splitting && !renderStack.isEmpty()) {
                renderStack = renderStack.copyWithCount(renderStack.getCount() / 2);
            } else if (quickCrafting && quickCraftSlots != null && quickCraftSlots.contains(slot) && !carried.isEmpty()) {
                if (quickCraftSlots.size() <= 1) continue;
                if (AbstractContainerMenu.canItemQuickReplace(slot, carried, true) && menu.canDragTo(slot)) {
                    drawQuickCraftGhost = true;
                    int maxStackSize = Math.min(carried.getMaxStackSize(), slot.getMaxStackSize(carried));
                    int existingCount = slot.getItem().isEmpty() ? 0 : slot.getItem().getCount();
                    int placeCount = quickCraftBasePlaceCount + existingCount;
                    if (placeCount > maxStackSize) {
                        placeCount = maxStackSize;
                        overlayText = ChatFormatting.YELLOW + String.valueOf(maxStackSize);
                    }
                    renderStack = carried.copyWithCount(placeCount);
                }
            }

            if (renderStack.isEmpty()) continue;

            int drawX = leftPos + slot.x + (int) Math.round((visual.slotSize - 16) / 2.0);
            int drawY = topPos + slot.y + (int) Math.round((visual.slotSize - 16) / 2.0);

            Slot slotElement = boundElementByMenuSlot.get(slot);
            final ItemStack finalRenderStack = renderStack;
            final String finalOverlayText = overlayText;
            final boolean finalDrawQuickCraftGhost = drawQuickCraftGhost;
            final int finalDrawX = drawX;
            final int finalDrawY = drawY;
            Runnable drawAction = () -> {
                guiGraphics.pose().pushPose();
                guiGraphics.pose().translate(0.0D, 0.0D, 100.0D + visual.zIndex);
                if (finalDrawQuickCraftGhost) {
                    int ghostSize = Math.max(1, Math.round(16.0F * visual.iconScale));
                    int ghostX = Math.round(finalDrawX + 8.0F - ghostSize / 2.0F);
                    int ghostY = Math.round(finalDrawY + 8.0F - ghostSize / 2.0F);
                    guiGraphics.fill(ghostX, ghostY, ghostX + ghostSize, ghostY + ghostSize, QUICK_CRAFT_GHOST_COLOR);
                }
                applyItemScaleTransform(guiGraphics, finalDrawX, finalDrawY, visual.iconScale);
                guiGraphics.renderItem(finalRenderStack, finalDrawX, finalDrawY, slot.x + slot.y * imageWidth);
                guiGraphics.renderItemDecorations(font, finalRenderStack, finalDrawX, finalDrawY, finalOverlayText);
                guiGraphics.pose().popPose();
            };
            if (slotElement == null) {
                drawAction.run();
            } else {
                ItemRender.withInheritedClip(slotElement, drawAction);
            }
        }
    }

    private void drawDisplaySlotItems(GuiGraphics guiGraphics) {
        // Keep bound-slot rendering specialized for container screens.
        // Display-only slot items are rendered via the shared pass.
        ItemRender.renderDisplaySlotItems(guiGraphics, new ArrayList<>(unboundSlots));
    }

    private void drawSlotHoverTooltipByElement(GuiGraphics guiGraphics, int mouseX, int mouseY) {
        if (linkedDocument == null) return;

        List<Element> elements = linkedDocument.getElements();
        for (int index = elements.size() - 1; index >= 0; index--) {
            Element element = elements.get(index);
            if (!(element instanceof MinecraftElement minecraftElement)) continue;
            if (!minecraftElement.isHover) continue;

            ItemStack stack = minecraftElement.getTooltipStack();
            if (stack.isEmpty()) continue;
            minecraftElement.renderTooltip(guiGraphics, mouseX, mouseY);
            return;
        }

        if (hoveredSlot != null && hoveredSlot.isActive() && isSlotPointerInteractable(hoveredSlot)) {
            ItemStack stack = hoveredSlot.getItem();
            if (!stack.isEmpty()) {
                guiGraphics.renderTooltip(font, stack, mouseX, mouseY);
                return;
            }
        }

        int slotIndex = findSlotIndexAt(mouseX, mouseY);
        if (slotIndex < 0 || slotIndex >= menu.slots.size()) return;

        net.minecraft.world.inventory.Slot menuSlot = menu.slots.get(slotIndex);
        if (!menuSlot.isActive()) return;
        ItemStack stack = menuSlot.getItem();
        if (stack.isEmpty()) return;

        guiGraphics.renderTooltip(font, stack, mouseX, mouseY);
    }

    private void drawDevToolsOverlay(GuiGraphics guiGraphics) {
        var devToolsDocuments = Document.get(DEVTOOLS_PATH);
        if (devToolsDocuments.isEmpty()) return;

        Document devToolsDocument = devToolsDocuments.get(0);
        if (devToolsDocument == null || devToolsDocument.body == null) return;
        if (devToolsDocument == linkedDocument) return;
        Base.drawScreenDocument(guiGraphics.pose(), devToolsDocument);
    }

    @Override
    public void onClose() {
        if (linkedDocument == null) {
            super.onClose();
            return;
        }

        if (linkedDocument.body != null) {
            Event.triggerSingle(new Event(linkedDocument.body, "unload", false));
        }

        linkedDocument.remove();
        Cursor.resetToDefault();
        super.onClose();
    }

    @Override
    public void removed() {
        // 兜底清理：某些关闭路径可能不经过 onClose，确保绑定文档不会残留。
        if (linkedDocument != null) {
            linkedDocument.remove();
        }
        clearSlotBindings();
        super.removed();
    }

    private void clearSlotBindings() {
        slotsBound = false;
        slotSyncDirty = true;
        lastKnownDomSlotCount = -1;
        lastBindGeneration = -1L;
        boundSlots.clear();
        unboundSlots.clear();
        boundGlobalIndexByElement.clear();
        boundContainerByElement.clear();
        boundElementByMenuSlot.clear();
    }

    private SlotVisual resolveSlotVisual(net.minecraft.world.inventory.Slot slot) {
        if (!(slot instanceof ApricityContainerMenu.UiSlot uiSlot)) {
            return new SlotVisual(16, false, true, true, 1.0F, 0, false);
        }
        return new SlotVisual(
                Math.max(1, uiSlot.getUiSlotSize()),
                uiSlot.isUiDisabled(),
                uiSlot.isUiRenderItem(),
                uiSlot.isUiAcceptPointer(),
                Math.max(0.01F, uiSlot.getUiIconScale()),
                uiSlot.getUiZIndex(),
                uiSlot.isUiHidden()
        );
    }

    private int resolveSlotSize(net.minecraft.world.inventory.Slot slot) {
        if (slot instanceof ApricityContainerMenu.UiSlot uiSlot) {
            return Math.max(1, uiSlot.getUiSlotSize());
        }
        return 16;
    }

    private boolean applyBoundSlotRuntimeStyle(
            Slot slotElement,
            boolean hidden
    ) {
        if (slotElement == null) return false;
        String baseStyle = (String) slotElement.getRuntimeCache("bound-base-inline-style");
        if (baseStyle == null) {
            String raw = slotElement.getAttribute("style");
            baseStyle = raw == null ? "" : raw;
            slotElement.putRuntimeCache("bound-base-inline-style", baseStyle);
        }

        String runtimeStyle = hidden ? "display:none;" : "";
        String merged = mergeInlineStyle(baseStyle, runtimeStyle);

        String lastApplied = (String) slotElement.getRuntimeCache("bound-last-inline-style");
        if (Objects.equals(lastApplied, merged)) return false;
        slotElement.setAttribute("style", merged);
        slotElement.putRuntimeCache("bound-last-inline-style", merged);
        slotElement.putRuntimeCache("bound-runtime-layout-managed", hidden);
        return true;
    }

    private static String mergeInlineStyle(String baseStyle, String runtimeStyle) {
        String base = baseStyle == null ? "" : baseStyle.trim();
        String runtime = runtimeStyle == null ? "" : runtimeStyle.trim();
        if (base.isEmpty()) return runtime;
        if (runtime.isEmpty()) return base;
        if (base.endsWith(";")) return base + runtime;
        return base + ";" + runtime;
    }

    private void setMenuSlotPosition(net.minecraft.world.inventory.Slot slot, int x, int y) {
        if (slot == null) return;
        SlotAccessor accessor = (SlotAccessor) slot;
        accessor.setX(x);
        accessor.setY(y);
    }

    private static void applyItemScaleTransform(GuiGraphics guiGraphics, int drawX, int drawY, float iconScale) {
        if (Math.abs(iconScale - 1.0F) <= ICON_SCALE_EPSILON) return;
        float centerX = drawX + 8.0F;
        float centerY = drawY + 8.0F;
        guiGraphics.pose().translate(centerX, centerY, 0.0D);
        guiGraphics.pose().scale(iconScale, iconScale, 1.0F);
        guiGraphics.pose().translate(-centerX, -centerY, 0.0D);
    }

    private record SlotVisual(
            int slotSize,
            boolean disabled,
            boolean renderItem,
            boolean acceptPointer,
            float iconScale,
            int zIndex,
            boolean hidden
    ) {
    }
}
