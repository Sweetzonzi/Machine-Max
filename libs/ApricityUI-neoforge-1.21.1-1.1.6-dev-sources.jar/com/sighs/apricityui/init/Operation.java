package com.sighs.apricityui.init;
import com.sighs.apricityui.dev.DevTools;
import com.sighs.apricityui.dev.ResourceManager;
import com.sighs.apricityui.element.AbstractText;
import com.sighs.apricityui.element.Input;
import com.sighs.apricityui.element.TextArea;
import com.sighs.apricityui.event.KeyEvent;
import com.sighs.apricityui.event.MouseEvent;
import com.sighs.apricityui.instance.Client;
import com.sighs.apricityui.instance.ClientLoader;
import com.sighs.apricityui.registry.Keybindings;
import com.sighs.apricityui.style.Position;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;

public class Operation {
    public static Position cachedMousePosition = null;
    private static int mouseButtons = 0;
    private static final long KEY_DEDUP_WINDOW_NS = 5_000_000L; // 5ms
    private static long lastKeyEventTimeNs = 0L;
    private static int lastKeyCode = -1;
    private static int lastScanCode = -1;
    private static int lastAction = -1;
    private static int lastModifiers = -1;

    public static boolean onMouseDown() {
        return onMouseDown(-1);
    }

    public static boolean onMouseDown(int button) {
        mouseButtons |= buttonMask(button);
        MouseEvent event = new MouseEvent("mousedown", getMousePosition(), button);
        event.setTrusted(true);
        return MouseEvent.tiggerEvent(event);
    }

    public static boolean onMouseUp() {
        return onMouseUp(-1);
    }

    public static boolean onMouseUp(int button) {
        mouseButtons &= ~buttonMask(button);
        MouseEvent event = new MouseEvent("mouseup", getMousePosition(), button);
        event.setTrusted(true);
        return MouseEvent.tiggerEvent(event);
    }

    public static void onMouseMove(Position currentMousePosition) {
        if (cachedMousePosition != null) {
            MouseEvent mouseEvent = new MouseEvent("mousemove", getMousePosition());
            mouseEvent.movementX = currentMousePosition.x - cachedMousePosition.x;
            mouseEvent.movementY = currentMousePosition.y - cachedMousePosition.y;
            mouseEvent.setTrusted(true);
            MouseEvent.tiggerEvent(mouseEvent);
        }
        cachedMousePosition = currentMousePosition;
    }

    public static boolean scroll(double delta) {
        MouseEvent mouseEvent = new MouseEvent("wheel", getMousePosition());
        mouseEvent.deltaY = -delta * 50;
        mouseEvent.scrollDelta = mouseEvent.deltaY;
        mouseEvent.cancelable = true;
        mouseEvent.setTrusted(true);
        return MouseEvent.tiggerEvent(mouseEvent);
    }

    public static int getMouseButtons() {
        return mouseButtons;
    }

    private static int buttonMask(int button) {
        return switch (button) {
            case 0 -> 1;
            case 1 -> 2;
            case 2 -> 4;
            case 3 -> 8;
            case 4 -> 16;
            default -> 0;
        };
    }

    public static boolean onCharTyped(char code) {
        boolean shouldCancel = false;
        for (Document document : Document.getAll()) {
            if (document.getFocusedElement() instanceof AbstractText textElement && textElement.canEditText()) {
                Event.runTrustedAction(() -> textElement.insertText(Character.toString(code)));
                shouldCancel = true;
            }
        }
        return shouldCancel;
    }

    public static boolean onKeyPressed(int key) {
        return onKeyPressed(key, false);
    }

    public static boolean onKeyPressed(int key, boolean repeat) {
        return onKeyPressed(key, 0, 0, repeat, KeyEvent.Source.INPUT_EVENT);
    }

    public static boolean onKeyPressed(int key, int scanCode, int modifiers, boolean repeat, KeyEvent.Source source) {
        boolean cancel = false;
        for (Document document : Document.getAll()) {
            final boolean[] documentCanceled = {false};
            Event.runTrustedAction(() -> {
                KeyEvent.triggerEvent(document, "keydown", key, scanCode, modifiers, repeat, source);
                Element focusedElement = document.getFocusedElement();
                String selectedText = resolveSelectedText(document, focusedElement);

                if (focusedElement instanceof AbstractText textElement) {
                    if (isCtrlDown()) {
                        if (key == GLFW.GLFW_KEY_A) {
                            if (textElement.canSelectText()) {
                                textElement.selectAll();
                                documentCanceled[0] = true;
                                return;
                            }
                        }
                        if (key == GLFW.GLFW_KEY_C) {
                            if (textElement.canSelectText() && !selectedText.isEmpty()) {
                                setClipboardText(selectedText);
                                documentCanceled[0] = true;
                                return;
                            }
                        }
                        if (key == GLFW.GLFW_KEY_X) {
                            if (textElement.canEditText() && textElement.hasSelection()) {
                                if (!selectedText.isEmpty()) setClipboardText(selectedText);
                                textElement.replaceSelection("");
                                documentCanceled[0] = true;
                                return;
                            }
                        }
                        if (key == GLFW.GLFW_KEY_V) {
                            if (textElement.canEditText()) {
                                textElement.insertText(getClipboardText());
                                documentCanceled[0] = true;
                                return;
                            }
                        }
                        if (key == GLFW.GLFW_KEY_Z) {
                            if (textElement.canEditText() && textElement.undo()) {
                                documentCanceled[0] = true;
                                return;
                            }
                        }
                    }

                    if (focusedElement instanceof Input input && key == GLFW.GLFW_KEY_SPACE && input.handleSpaceKey()) {
                        documentCanceled[0] = true;
                        return;
                    }

                    if (!textElement.canEditText()) return;

                    if (key == GLFW.GLFW_KEY_BACKSPACE) {
                        textElement.deleteBackward();
                        documentCanceled[0] = true;
                    } else if (key == GLFW.GLFW_KEY_DELETE) {
                        textElement.deleteForward();
                        documentCanceled[0] = true;
                    } else if (key == GLFW.GLFW_KEY_LEFT) {
                        textElement.moveCursor(-1, isShiftDown() && textElement.canSelectText());
                        documentCanceled[0] = true;
                    } else if (key == GLFW.GLFW_KEY_RIGHT) {
                        textElement.moveCursor(1, isShiftDown() && textElement.canSelectText());
                        documentCanceled[0] = true;
                    } else if (key == GLFW.GLFW_KEY_ENTER) {
                        if (focusedElement instanceof TextArea) {
                            textElement.insertText("\n");
                        } else {
                            if (!focusedElement.submitEnclosingForm()) {
                                document.clearFocus();
                            }
                        }
                        documentCanceled[0] = true;
                    } else if (key == GLFW.GLFW_KEY_ESCAPE) {
                        document.clearFocus();
                        documentCanceled[0] = true;
                    }
                } else if (focusedElement != null) {
                    if (isCtrlDown()) {
                        if (key == GLFW.GLFW_KEY_A && focusedElement.canSelectInnerText()) {
                            focusedElement.selectAllInnerText();
                            documentCanceled[0] = true;
                            return;
                        }
                        if (key == GLFW.GLFW_KEY_C && focusedElement.canSelectInnerText() && !selectedText.isEmpty()) {
                            setClipboardText(selectedText);
                            documentCanceled[0] = true;
                            return;
                        }
                    }
                    if (key == GLFW.GLFW_KEY_ESCAPE && focusedElement.canSelectInnerText()) {
                        focusedElement.clearTextSelection();
                        document.clearFocus();
                        documentCanceled[0] = true;
                    }
                }
            });
            cancel |= documentCanceled[0];
        }
        if (!repeat && key == GLFW.GLFW_KEY_F12) {
            DevTools.toggle();
        }
        if (!repeat && key == GLFW.GLFW_KEY_F10) {
            ResourceManager.toggle();
        }
        if (!repeat && key == Keybindings.RELOAD.getKey().getValue()) {
            ClientLoader.reload();
        }
        return cancel;
    }

    public static void onKeyReleased(int key) {
        onKeyReleased(key, 0, 0, KeyEvent.Source.INPUT_EVENT);
    }

    public static void onKeyReleased(int key, int scanCode, int modifiers, KeyEvent.Source source) {
        for (Document document : Document.getAll()) {
            KeyEvent.triggerEvent(document, "keyup", key, scanCode, modifiers, false, source);
        }
    }

    private static String getSelectedTextFromElement(Element element) {
        if (element == null) return "";
        if (element instanceof AbstractText textElement) {
            String selected = textElement.getSelectedText();
            return selected == null ? "" : selected;
        }
        if (element.canSelectInnerText()) {
            String selected = element.getSelectedInnerText();
            return selected == null ? "" : selected;
        }
        return "";
    }

    private static String resolveSelectedText(Document document, Element focusedElement) {
        String selected = getSelectedTextFromElement(focusedElement);
        if (!selected.isEmpty()) return selected;

        Element active = document.getPressedElement();
        if (active != focusedElement) {
            selected = getSelectedTextFromElement(active);
            if (!selected.isEmpty()) return selected;
        }

        for (Element element : document.getElements()) {
            selected = getSelectedTextFromElement(element);
            if (!selected.isEmpty()) return selected;
        }
        return "";
    }

    /**
     * FIXME:
     * 如果在某些情况（如窗口拖动等）鼠标位置缓存为空或者是读到旧的缓存值时请参考{@link #getMousePositionDirectly()}
     * 未来建议重构，统一输入源，或在输入更新链中保证鼠标坐标始终同步。
     *
     * @see Client#getMousePosition()
     */
    public static Position getMousePosition() {
        return cachedMousePosition;
    }

    public static Position getMousePositionDirectly() {
        Position live = Client.getMousePositionDirectly();
        if (live != null) {
            if (cachedMousePosition == null) {
                cachedMousePosition = live;
            }
            return live;
        }
        return cachedMousePosition;
    }

    private static boolean isCtrlDown() {
        return isKeyPressed("key.keyboard.left.control") || isKeyPressed("key.keyboard.right.control");
    }

    private static boolean isShiftDown() {
        return isKeyPressed("key.keyboard.left.shift") || isKeyPressed("key.keyboard.right.shift");
    }

    public static String getClipboardText() {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft == null || minecraft.keyboardHandler == null) return "";
        String text = minecraft.keyboardHandler.getClipboard();
        return text == null ? "" : text;
    }

    public static void setClipboardText(String text) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft == null || minecraft.keyboardHandler == null) return;
        minecraft.keyboardHandler.setClipboard(text == null ? "" : text);
    }

    public static boolean isKeyPressed(String key) {
        return Client.isKeyPressed(key);
    }

    public static boolean handleKeyInput(int key, int scanCode, int action, int modifiers, boolean repeat, KeyEvent.Source source) {
        if (isDuplicateKeyEvent(key, scanCode, action, modifiers)) {
            return false;
        }
        if (action == GLFW.GLFW_RELEASE) {
            onKeyReleased(key, scanCode, modifiers, source);
            return false;
        }
        return onKeyPressed(key, scanCode, modifiers, repeat, source);
    }

    private static boolean isDuplicateKeyEvent(int key, int scanCode, int action, int modifiers) {
        long now = System.nanoTime();
        if (key == lastKeyCode
                && scanCode == lastScanCode
                && action == lastAction
                && modifiers == lastModifiers
                && (now - lastKeyEventTimeNs) <= KEY_DEDUP_WINDOW_NS) {
            return true;
        }
        lastKeyEventTimeNs = now;
        lastKeyCode = key;
        lastScanCode = scanCode;
        lastAction = action;
        lastModifiers = modifiers;
        return false;
    }

}
