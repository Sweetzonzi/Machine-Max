package cn.solarmoon.spark_core.sound;

import cn.solarmoon.spark_core.SparkCore;
import cn.solarmoon.spark_core.api.SpreadingSoundHelper;
import cn.solarmoon.spark_core.pack.modules.SoundModule;
import cn.solarmoon.spark_core.registry.common.SparkSounds;
import com.mojang.blaze3d.audio.SoundBuffer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.sound.PlaySoundSourceEvent;
import org.jetbrains.annotations.Nullable;

import javax.sound.sampled.AudioFormat;
import java.nio.ByteBuffer;
import java.util.*;

/**
 * 带音速传播(非简单延迟，而是波面抵达收听者)和多普勒效应的音效实例
 * 声音传播范围的实现参考自https://github.com/MCModderAnchor/TACZ
 */
@OnlyIn(Dist.CLIENT)
@EventBusSubscriber(value = Dist.CLIENT)
public class SpreadingSoundInstance extends AbstractTickableSoundInstance {
    private static final int MAX_SOUND_POINTS = 200; // 单实例最大声源点数量(10秒)

    public UUID uuid = UUID.randomUUID();
    @Nullable
    public final ISoundSpreader ISoundSpreader;
    private final SoundEvent soundEvent;
    public final float maxRange;

    // 声音传播点数据
    public final LinkedList<SoundSourcePoint> soundPoints = new LinkedList<>();
    // 声音传播范围的AABB边界框，用于快速剔除
    private AABB spreadAABB;

    public boolean isPlaying = false;
    public Vec3 speed = Vec3.ZERO;

    // 淡入淡出相关
    private final int fadeInTicks;
    private final int fadeOutTicks;
    private int fadeProgress; // 当前淡入淡出进度（正数表示淡入，负数表示淡出）
    private float fadeFactor; // 声音淡入淡出因子，用于计算声音的最终音量
    private boolean isFadingOut = false;
    private boolean shouldGenerateNewPoints = true;

    /**
     * <p>针对单次声源的构造函数，用于创建单个定点声源的音效实例</p>
     *
     * @param soundEvent 声音事件，随用随建时可用于分辨来自同一源的不同声音
     * @param soundType  声音类型，方块，环境等
     * @param position   声音位置
     * @param speed      声音发出时的速度
     * @param pitch      声音的音高
     * @param volume     声音的音量
     * @param fadeInTicks   声音淡入的时长，单位：tick
     * @param fadeOutTicks  声音淡出的时长，单位：tick
     */
    public SpreadingSoundInstance(SoundEvent soundEvent, SoundSource soundType, Vec3 position, Vec3 speed, float pitch, float volume, int fadeInTicks, int fadeOutTicks, boolean loop) {
        super(SparkSounds.getCUSTOM_SOUND().get(), soundType, SoundInstance.createUnseededRandom());
        this.ISoundSpreader = null;
        this.attenuation = Attenuation.NONE;//衰减根据与听者的距离自动调整
        this.soundEvent = soundEvent;
        this.x = position.x;
        this.y = position.y;
        this.z = position.z;
        this.pitch = pitch;
        this.volume = volume;
        this.maxRange = soundEvent.getRange(1.0f);
        this.fadeInTicks = fadeInTicks;
        this.fadeOutTicks = fadeOutTicks;
        this.fadeProgress = (fadeInTicks > 0) ? 0 : 1; // 如果没有淡入，立即完成
        this.fadeFactor = fadeProgress;
        this.looping = loop;
        // 创建初始声音点
        SoundSourcePoint soundPoint = new SoundSourcePoint(position, speed, pitch, volume);
        this.soundPoints.add(soundPoint);
        // 初始化AABB
        updateAABB();
    }

    /**
     * <p>针对持续发出声音的声源的构造函数，用于创建位置速度音高等时刻改变声源的音效实例</p>
     *
     * @param soundEvent    声音事件，随用随建时可用于分辨来自同一源的不同声音
     * @param soundType     声音类型，方块，环境等
     * @param soundSpreader 声源，音效会通过接口提供的方法更新其位置
     * @param fadeInTicks   声音淡入的时长，单位：tick
     * @param fadeOutTicks  声音淡出的时长，单位：tick
     */
    public SpreadingSoundInstance(SoundEvent soundEvent, SoundSource soundType, ISoundSpreader soundSpreader, int fadeInTicks, int fadeOutTicks, boolean loop) {
        super(SparkSounds.getCUSTOM_SOUND().get(), soundType, SoundInstance.createUnseededRandom());
        this.ISoundSpreader = soundSpreader;
        this.attenuation = Attenuation.NONE;//衰减根据与听者的距离自动调整
        this.soundEvent = soundEvent;
        var position = soundSpreader.getPosition(this.uuid, soundEvent);
        this.x = position.x;
        this.y = position.y;
        this.z = position.z;
        this.maxRange = soundEvent.getRange(1.0f);
        this.pitch = soundSpreader.getPitch(this.uuid, soundEvent);
        this.volume = soundSpreader.getVolume(this.uuid, soundEvent);
        this.speed = soundSpreader.getSpeed(this.uuid, soundEvent);
        this.fadeInTicks = fadeInTicks;
        this.fadeOutTicks = fadeOutTicks;
        this.fadeProgress = (fadeInTicks > 0) ? 0 : 1; // 如果没有淡入，立即完成
        this.fadeFactor = fadeProgress;
        this.looping = loop;
        // 创建初始声音点
        SoundSourcePoint soundPoint = new SoundSourcePoint(position, soundSpreader.getSpeed(this.uuid, soundEvent), this.pitch, this.volume);
        this.soundPoints.add(soundPoint);
        // 初始化AABB
        updateAABB();
    }

    @Override
    public void tick() {
        // 更新淡入淡出状态
        updateFadeState();
        if(this.isStopped()) return;

        // 更新声音传播状态
        Iterator<SoundSourcePoint> iterator = this.soundPoints.iterator();
        // 更新传播距离和生成新声源点
        while (iterator.hasNext()) {
            SoundSourcePoint soundPoint = iterator.next();

            if (soundPoint.getSpreadDistance() > this.maxRange) {
                // 移除已达到传播范围上限的声源
                iterator.remove();
                continue;
            }

            // 计算传播速度并更新距离
            float speed = getSoundSpeed(
                    soundPoint.getPosition().scale(0.5)
                            .add(Minecraft.getInstance().gameRenderer.getMainCamera().getPosition().scale(0.5)),
                    Minecraft.getInstance().level);
            soundPoint.setSpreadDistance(soundPoint.getSpreadDistance() + speed * 0.05f);
        }

        // 持续产生波面：循环声源（looping）或动态声源（ISoundSpreader），每tick生成一个新的波面
        // 非循环的静态声源仅使用构造函数中创建的初始波面，波面耗尽后由下方逻辑自动停止
        if (shouldGenerateNewPoints && (looping || ISoundSpreader != null)) {
            Vec3 pointPos;
            float pointPitch;
            float pointVolume;
            Vec3 pointSpeed;

            if (ISoundSpreader != null) {
                // 动态声源：从ISoundSpreader获取实时位置、速度、音高、音量
                pointPos = ISoundSpreader.getPosition(this.uuid, getSoundEvent());
                pointPitch = ISoundSpreader.getPitch(this.uuid, getSoundEvent());
                pointVolume = ISoundSpreader.getVolume(this.uuid, getSoundEvent());
                pointSpeed = ISoundSpreader.getSpeed(this.uuid, getSoundEvent());
            } else {
                // 循环静态声源：从当前位置持续发射波面
                pointPos = new Vec3(x, y, z);
                pointPitch = pitch;
                pointVolume = volume;
                pointSpeed = speed;
            }

            SoundSourcePoint newPoint = new SoundSourcePoint(pointPos, pointSpeed, pointPitch, pointVolume);
            this.soundPoints.add(newPoint);
            if (this.soundPoints.size() > MAX_SOUND_POINTS) {
                this.soundPoints.removeFirst(); // 限制声源点数量
            }
        }

        // 静态声源的波面在播放前耗尽时，停止未启动的实例以释放资源。
        // 已开始播放的实例交由原版 SoundEngine 在音频结束后清理。
        if (soundPoints.isEmpty() && ISoundSpreader == null && !isPlaying) {
            stop();
            return;
        }

        // 更新传播范围的AABB
        updateAABB();
    }

    /**
     * 更新淡入淡出进度
     */
    private void updateFadeState() {
        if (fadeProgress <= fadeInTicks && !isFadingOut) {
            // 淡入阶段
            this.fadeProgress++;
            float t = Math.clamp((float) fadeProgress / fadeInTicks, 0.0f, 1.0f);
            // 使用平方根曲线实现等功率淡入
//            this.fadeFactor = (float) Math.sqrt(t);
//            this.fadeFactor = t;
            this.fadeFactor = (1.0f - (float) Math.cos(t * Math.PI)) * 0.5f;  // 余弦曲线
        } else if (isFadingOut) {
            // 淡出完成且没有活跃波面时停止
            if (fadeProgress <= -fadeOutTicks && soundPoints.isEmpty()) {
                this.fadeFactor = 0.0f;
                this.volume = 0.0f;
                this.stop();
                return;
            }
            // 淡出阶段
            this.fadeProgress--;
            float t = Math.clamp(1.0f - (float) fadeProgress / (-fadeOutTicks), 0.0f, 1.0f);
            // 使用平方根曲线实现等功率淡出
//            this.fadeFactor = (float) Math.sqrt(t);
//            this.fadeFactor = t;
            this.fadeFactor = (1.0f - (float) Math.cos(t * Math.PI)) * 0.5f;  // 余弦曲线
        }
    }

    /**
     * 开始淡出
     */
    public void startFadeOut() {
        this.isFadingOut = true;
        this.shouldGenerateNewPoints = false;
        if (fadeOutTicks <= 0){
            stopImmediately();
            return;
        }
        this.fadeProgress = 1; // 从当前进度开始淡出，晚1tick以等待过渡音效开始播放
    }

    /**
     * 立即停止播放
     */
    public void stopImmediately() {
        this.soundPoints.clear();
        this.fadeProgress = -1; // 从当前进度开始淡出
        this.fadeFactor = 0.0f;
        this.volume = 0.0f;
        this.stop();
    }

    /**
     * 从另一声音实例复制传播状态
     * @param other 另一声音实例
     */
    public void copySoundPointsFrom(SpreadingSoundInstance other) {
        this.soundPoints.clear();
        this.soundPoints.addAll(other.soundPoints);
        this.x = other.x;
        this.y = other.y;
        this.z = other.z;
        this.speed = other.speed;
        if(this.ISoundSpreader != null) {
            this.pitch = this.ISoundSpreader.getPitch(this.uuid, this.soundEvent);
            this.volume = this.ISoundSpreader.getVolume(this.uuid, this.soundEvent);
        }else{
            this.pitch = other.pitch;
            this.volume = other.volume;
        }
        // 更新AABB
        this.updateAABB();
    }

    /**
     * 更新声音传播范围的AABB
     */
    public void updateAABB() {
        if (soundPoints.isEmpty()) {
            // 如果没有声源点，使用一个很小的AABB
            this.spreadAABB = new AABB(x - 0.5, y - 0.5, z - 0.5, x + 0.5, y + 0.5, z + 0.5);
            return;
        }

        double minX = Double.MAX_VALUE;
        double minY = Double.MAX_VALUE;
        double minZ = Double.MAX_VALUE;
        double maxX = -Double.MAX_VALUE;
        double maxY = -Double.MAX_VALUE;
        double maxZ = -Double.MAX_VALUE;

        for (SoundSourcePoint point : soundPoints) {
            Vec3 pos = point.getPosition();
            float spread = point.getSpreadDistance();

            // 计算该声源点当前传播范围的边界
            minX = Math.min(minX, pos.x - spread);
            minY = Math.min(minY, pos.y - spread);
            minZ = Math.min(minZ, pos.z - spread);
            maxX = Math.max(maxX, pos.x + spread);
            maxY = Math.max(maxY, pos.y + spread);
            maxZ = Math.max(maxZ, pos.z + spread);
        }

        // 添加一些容差，确保边界足够
        double tolerance = 1.0;
        this.spreadAABB = new AABB(
                minX - tolerance, minY - tolerance, minZ - tolerance,
                maxX + tolerance, maxY + tolerance, maxZ + tolerance
        );
    }

    /**
     * 获取当前声音传播范围的AABB
     */
    public AABB getSpreadAABB() {
        return spreadAABB;
    }

    /**
     * 检查收听者是否在声音传播范围内
     */
    public boolean isListenerInRange(Vec3 listenerPos) {
        return spreadAABB.contains(listenerPos);
    }

    /**
     * 应用指定的声源点属性到声音实例
     */
    public void applySoundPoint(SoundSourcePoint soundPoint) {
        this.x = soundPoint.getPosition().x;
        this.y = soundPoint.getPosition().y;
        this.z = soundPoint.getPosition().z;
        this.pitch = soundPoint.getPitch();
        this.volume = soundPoint.getVolume();
        this.speed = soundPoint.getSpeed();
        removeSoundPoint(soundPoint);
    }

    /**
     * 获取所有已到达收听者的声源点（按抵达时间排序）
     */
    public List<SoundSourcePoint> getReachedSoundPoints(Vec3 listenerPos) {
        List<SoundSourcePoint> reachedPoints = new ArrayList<>();
        for (SoundSourcePoint soundPoint : this.soundPoints) {
            if (soundPoint.hasReachedListener(listenerPos)) {
                reachedPoints.add(soundPoint);
            }
        }
        // 按传播距离排序（先到达的在前）
        reachedPoints.sort(Comparator.comparingDouble(SoundSourcePoint::getSpreadDistance));
        return reachedPoints;
    }

    /**
     * 移除指定的声源点
     */
    public void removeSoundPoint(SoundSourcePoint point) {
        this.soundPoints.remove(point);
    }

    @Nullable
    public SoundBuffer getSoundBuffer() {
        ResourceLocation location = getSoundEvent().getLocation();
        SoundData soundData = null;

        // ★ 车内/车外音效差异化：依次查找 _interior 后缀变体
        if (ISoundSpreader != null) {
            var cameraEntity = Minecraft.getInstance().getCameraEntity();
            boolean isFirstPerson = Minecraft.getInstance().options.getCameraType().isFirstPerson();
            if (ISoundSpreader.shouldApplyInteriorEffect(cameraEntity, getSoundEvent(), isFirstPerson)) {
                ResourceLocation interiorLoc = ResourceLocation.fromNamespaceAndPath(
                        location.getNamespace(), location.getPath() + "_interior");
                // 1. 先查 SoundModule 内的车内变体
                soundData = SoundModule.getSound(interiorLoc);
                // 2. 回退到原版 SoundManager 的车内变体
                if (soundData == null) {
                    SoundBuffer interiorBuffer = SpreadingSoundHelper.INSTANCE.getSoundBuffer(interiorLoc);
                    if (interiorBuffer != null) return interiorBuffer;
                }
            }
        }

        // 3. 回退到 SoundModule 内的通用版本
        if (soundData == null) {
            soundData = SoundModule.getSound(location);
        }

        // 4. 最终回退：原版 SoundManager 的通用版本
        if (soundData == null) {
            return SpreadingSoundHelper.INSTANCE.getSoundBuffer(location);
        }

        AudioFormat rawFormat = soundData.audioFormat();

        // 格式验证
        if (!isValidAudioFormat(rawFormat)) {
            SparkCore.LOGGER.error("Invalid audio format: {}", rawFormat);
            return null;
        }

        // 创建原始缓冲区的副本，避免并发修改
        ByteBuffer buffer = soundData.byteBuffer().duplicate();

        if (buffer == null || buffer.capacity() == 0) {
            SparkCore.LOGGER.error("Invalid audio buffer");
            return null;
        }

        // 确保缓冲区位置为0
        buffer.rewind();

        try {
            if (rawFormat.getChannels() > 1) {
                // 转换为单声道
                AudioFormat monoFormat = new AudioFormat(
                        rawFormat.getEncoding(),
                        rawFormat.getSampleRate(),
                        rawFormat.getSampleSizeInBits(),
                        1, // 单声道
                        rawFormat.getSampleSizeInBits() / 8, // 单声道帧大小
                        rawFormat.getSampleRate(),
                        rawFormat.isBigEndian(),
                        rawFormat.properties()
                );

                ByteBuffer monoBuffer = convertToMono(buffer, rawFormat);
                if (monoBuffer == null) {
                    return null;
                }

                return new SoundBuffer(monoBuffer, monoFormat);
            }

            return new SoundBuffer(buffer, rawFormat);
        } catch (Exception e) {
            SparkCore.LOGGER.error("Failed to create SoundBuffer", e);
            return null;
        }
    }

    @SubscribeEvent
    public static void onPlaySoundSource(PlaySoundSourceEvent event) {
        if (event.getSound() instanceof SpreadingSoundInstance instance) {
            SoundBuffer soundBuffer = instance.getSoundBuffer();

            if (soundBuffer != null) {
                event.getChannel().attachStaticBuffer(soundBuffer);//将声音作为buffer附加到一个空的音频中，实现任意自定义音效的播放
                event.getChannel().play();
            }
        }
    }

    public static float getSoundSpeed(Vec3 position, ClientLevel level) {
        //TODO:与高度挂钩，与介质挂钩，与维度设定挂钩
        return 100f;
    }

    public Vec3 getSpeed() {
        return this.speed != null ? this.speed : Vec3.ZERO;
    }

    public float getMaxRange() {
        return this.maxRange;
    }

    @Override
    public float getPitch() {
        return this.pitch;
    }

    @Override
    public float getVolume() {
        return this.volume * this.fadeFactor;
    }

    public void setPitch(float pitch) {
        this.pitch = pitch;
    }

    public void setVolume(float volume) {
        this.volume = volume;
    }

    public boolean isFadedOut() { return fadeProgress <= -fadeOutTicks; }
    public int getFadeProgress() { return fadeProgress; }
    public int getFadeInTicks() { return fadeInTicks; }
    public int getFadeOutTicks() { return fadeOutTicks; }
    public boolean shouldGenerateNewPoints() { return shouldGenerateNewPoints; }

    @Override
    public boolean canStartSilent() {
        return true;
    }

    public UUID getUUID() {
        return uuid;
    }

    public void setUUID(UUID uuid) {
        this.uuid = uuid;
    }

    public void setUUID(String uuid){
        this.uuid = UUID.fromString(uuid);
    }

    public SoundEvent getSoundEvent() {
        return this.soundEvent;
    }

    private boolean isValidAudioFormat(AudioFormat format) {
        return format.getSampleSizeInBits() == 16 &&
                format.getEncoding() == AudioFormat.Encoding.PCM_SIGNED &&
                format.getSampleRate() >= 8000 && format.getSampleRate() <= 48000;
    }

    /**
     * 将多声道音频转换为单声道
     */
    private ByteBuffer convertToMono(ByteBuffer source, AudioFormat format) {
        try {
            int channels = format.getChannels();
            int sampleSize = format.getSampleSizeInBits() / 8; // 字节数
            int frameSize = format.getFrameSize();
            int totalFrames = source.capacity() / frameSize;

            // 单声道缓冲区大小
            int monoSize = totalFrames * sampleSize;
            ByteBuffer monoBuffer = ByteBuffer.allocateDirect(monoSize);

            source.rewind();

            for (int frame = 0; frame < totalFrames; frame++) {
                long sum = 0;

                // 对每个声道的样本求和
                for (int channel = 0; channel < channels; channel++) {
                    int samplePos = frame * frameSize + channel * sampleSize;
                    source.position(samplePos);

                    if (sampleSize == 2) {
                        sum += source.getShort();
                    } else {
                        // 处理其他位深度
                        SparkCore.LOGGER.warn("Unsupported sample size: {}", sampleSize);
                        return null;
                    }
                }

                // 计算平均值并写入单声道缓冲区
                short monoSample = (short) (sum / channels);
                monoBuffer.putShort(monoSample);
            }

            monoBuffer.rewind();
            source.rewind(); // 恢复原始缓冲区位置

            return monoBuffer;
        } catch (Exception e) {
            SparkCore.LOGGER.error("Failed to convert to mono", e);
            return null;
        }
    }
}
