function AttackSystem:create()
end

