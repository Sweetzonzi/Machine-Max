---@class Vec3

