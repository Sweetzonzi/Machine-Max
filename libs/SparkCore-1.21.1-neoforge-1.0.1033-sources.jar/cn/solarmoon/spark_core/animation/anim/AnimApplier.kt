package cn.solarmoon.spark_core.animation.anim

import cn.solarmoon.spark_core.animation.IEntityAnimatable
import cn.solarmoon.spark_core.event.ItemStackInventoryTickEvent
import cn.solarmoon.spark_core.event.PhysicsEntityTickEvent
import cn.solarmoon.spark_core.registry.common.SparkCapabilities
import net.minecraft.world.entity.player.Player
import net.neoforged.bus.api.SubscribeEvent
import net.neoforged.neoforge.event.tick.EntityTickEvent

object AnimApplier {

    @SubscribeEvent
    private fun physTick(event: PhysicsEntityTickEvent) {
        val entity = event.entity
        if (entity is IEntityAnimatable<*>) {
            entity.animController.physTick()
        }

        if (entity is Player) {
            entity.inventory.items.forEach {
                it.getCapability(SparkCapabilities.ITEM_ANIMATABLE, entity.level())?.physicsTick()
            }
        }
    }

    @SubscribeEvent
    private fun entityTick(event: EntityTickEvent.Post) {
        val entity = event.entity
        if (entity is IEntityAnimatable<*>) {
            entity.animController.tick()

            if (entity.isSpectator) entity.animController.stopAllAnimation()
        }
        entity.lastPosO = entity.position()
    }

    @SubscribeEvent
    private fun itemTick(event: ItemStackInventoryTickEvent) {
        val stack = event.stack
        stack.getCapability(SparkCapabilities.ITEM_ANIMATABLE, event.entity.level())?.apply {
            inventoryTick(event.entity)
            animController.tick()
        }
    }

}
