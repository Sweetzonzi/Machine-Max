package cn.solarmoon.spark_core.animation.model.origin

import cn.solarmoon.spark_core.animation.model.ModelPose
import cn.solarmoon.spark_core.util.SerializeHelper
import com.mojang.serialization.Codec
import com.mojang.serialization.codecs.RecordCodecBuilder
import net.minecraft.network.FriendlyByteBuf
import net.minecraft.network.codec.ByteBufCodecs
import net.minecraft.network.codec.StreamCodec
import net.minecraft.world.phys.Vec3
import org.joml.Matrix3f
import org.joml.Matrix4f
import java.util.*

data class OBone(
    val name: String,
    val parentName: String?, // parent相当于在顶部的变换，给到所有子类
    val pivot: Vec3,
    val rotation: Vec3,
    val locators: LinkedHashMap<String, OLocator>,
    val cubes: List<OCube>,
    val mesh: OMesh? // 网格数据（可为null）
) {

    lateinit var rootModel: OModel

    init {
        cubes.forEach { it.rootBone = this }
        mesh?.rootBone = this // 建立网格与骨骼的关联
        locators.forEach { it.value.bone = this }
    }

    /**
     * 该骨骼是否应作为自发光骨骼渲染。
     *
     * 判定依据是模型格式通用的骨骼命名约定，在模型解析期只计算一次（后续访问为常量读取）：
     * - 名前缀 [GLOW_PREFIX] —— Yes Steve Model 导出的车灯/发光件命名
     * - 名后缀 [GLOW_SUFFIX] —— Blockbench 生态的 illuminated 发光标记
     * 两者均为大小写不敏感匹配，以兼容导出工具产生的 `ysmGLow`、`_Illuminated` 等写法。
     *
     * 此处仅描述模型数据自身的语义；发光用什么 RenderType、是否使用全亮光照，由渲染方决定。
     */
    val shouldGlow: Boolean =
        name.startsWith(GLOW_PREFIX, ignoreCase = true) || name.endsWith(GLOW_SUFFIX, ignoreCase = true)

    /**
     * 获取当前骨骼组的父组，没有就返回null
     */
    fun getParent(): OBone? = parentName?.let { rootModel.getBone(it) }

    /**
     * 判断当前骨骼是否是传入的骨骼的子代骨骼
     * @param bone 传入的骨骼
     */
    fun isChildOf(bone: OBone?): Boolean {
        if (bone == null) return false
        var isChild = false
        var parent = getParent()
        while (parent != null) {
            if (parent == bone) {
                isChild = true
                break
            }
            parent = parent.getParent()
        }
        return isChild
    }

    /**
     * 应用当前以及所有父骨骼的【法线变换】到 Matrix3f
     * - 不包含平移
     * - 正确处理旋转 + scale（inverse-transpose）
     */
    @JvmOverloads
    fun applyNormalTransformWithParents(
        pose: ModelPose,
        normal: Matrix3f,
        partialTick: Float = 1f,
        until: OBone? = null
    ): Matrix3f {
        val l = arrayListOf<OBone>(this)
        var parent = getParent()
        while (parent != null) {
            l.add(parent)
            if (parent == until) break
            parent = parent.getParent()
        }

        for (i in l.asReversed()) {
            val bonePose = pose.getBonePose(i.name)

            // 1. 拿到和 Matrix4f 完全一致的 local transform
            val m4 = bonePose.getLocalTransformMatrix(partialTick)

            // 2. 提取 normal matrix：inverse-transpose(upper-left 3x3)
            val n3 = Matrix3f(m4).invert().transpose()

            normal.mul(n3)
        }
        return normal
    }

    /**
     * 判断当前骨骼是否是传入的骨骼的子代骨骼
     * @param name 传入的骨骼的名字
     */
    fun isChildOf(name: String): Boolean = isChildOf(rootModel.getBone(name))

    /**
     * 应用当前以及所有父类的骨骼的变换到传入的矩阵中
     * @param pose 骨骼的变换数据
     * @param ma 要应用的矩阵
     * @param partialTick 插值进度
     * @param until 应用到哪个父骨骼为止(包括此父骨骼)，如果为null则应用至根骨骼
     */
    @JvmOverloads
    fun applyTransformWithParents(
        pose: ModelPose,
        ma: Matrix4f,
        partialTick: Float = 1f,
        until: OBone? = null
    ): Matrix4f {
        val l = arrayListOf<OBone>(this)
        var parent: OBone? = getParent()
        while (parent != null && until != this) {
            l.add(parent)
            if (parent == until) break
            parent = parent.getParent()
        }

        for (i in l.asReversed()) {
            pose.getBonePose(i.name).let { pose ->
                ma.mul(pose.getLocalTransformMatrix(partialTick))
            }
        }
        return ma
    }

    val tmpM4 = Matrix4f()

    /**
     * 计算当前骨骼层级变换对某个局部位姿（如 Locator）的最终影响。
     * * 此方法计算从根骨骼到当前骨骼的【原始静态变换】链，并将其作用于传入的局部矩阵 [ma]。
     * 通常用于计算一个“长”在骨骼上的点在模型空间中的绝对位置。
     * * @param ma 局部空间下的位姿矩阵（如 Locator 的相对位姿），执行后将变为模型空间位姿
     * @param until 停止追溯的父骨骼节点（包含），若为 null 则追溯至根骨骼
     * @return 返回应用了层级变换后的模型空间矩阵 tmpM4
     */
    @JvmOverloads
    fun applyTransformToLocal(
        ma: Matrix4f,
        until: OBone? = null
    ): Matrix4f {
        tmpM4.identity()
        val l = arrayListOf<OBone>(this)
        var parent: OBone? = getParent()
        while (parent != null && until != this) {
            l.add(parent)
            if (parent == until) break
            parent = parent.getParent()
        }

        for (bone in l.asReversed()) {
            if (bone.rotation.lengthSqr() < 1e-6) continue
            tmpM4.translate(bone.pivot.toVector3f())
            tmpM4.rotateZYX(bone.rotation.toVector3f())
            tmpM4.translate(bone.pivot.toVector3f().negate())
        }
        return tmpM4.mul(ma, ma)
    }

    companion object {
        /** 自发光骨骼名前缀 —— Yes Steve Model 导出约定 */
        const val GLOW_PREFIX = "ysmGlow"

        /** 自发光骨骼名后缀 —— Blockbench 生态约定 */
        const val GLOW_SUFFIX = "_illuminated"

        @JvmStatic
        val CODEC: Codec<OBone> = RecordCodecBuilder.create {
            it.group(
                Codec.STRING.fieldOf("name").forGetter { it.name },
                Codec.STRING.optionalFieldOf("parent").forGetter { Optional.ofNullable(it.parentName) },
                Vec3.CODEC.optionalFieldOf("pivot", Vec3.ZERO).forGetter { it.pivot },
                Vec3.CODEC.optionalFieldOf("rotation", Vec3.ZERO).forGetter { it.rotation },
                OLocator.MAP_CODEC.optionalFieldOf("locators", linkedMapOf()).forGetter { it.locators },
                OCube.LIST_CODEC.optionalFieldOf("cubes", arrayListOf()).forGetter { it.cubes },
                OMesh.CODEC.optionalFieldOf("poly_mesh").forGetter { Optional.ofNullable(it.mesh) } // 网格数据
            ).apply(it) { name, parent, pivot, rotation, locators, cubes, mesh ->
                OBone(name, parent.orElse(null), pivot, rotation, LinkedHashMap(locators), ArrayList(cubes), mesh.orElse(null))
            }
        }

        @JvmStatic
        val MAP_CODEC: Codec<LinkedHashMap<String, OBone>> = CODEC.listOf().xmap(
            { LinkedHashMap(it.associateBy { it -> it.name }) },
            { it.values.toList() }
        )

        @JvmStatic
        val STREAM_CODEC = object : StreamCodec<FriendlyByteBuf, OBone> {
            override fun decode(buffer: FriendlyByteBuf): OBone {
                val name = ByteBufCodecs.STRING_UTF8.decode(buffer)
                val parentName = ByteBufCodecs.optional(ByteBufCodecs.STRING_UTF8).decode(buffer).orElse(null)
                val pivot = SerializeHelper.VEC3_STREAM_CODEC.decode(buffer)
                val rotation = SerializeHelper.VEC3_STREAM_CODEC.decode(buffer)
                val locators = OLocator.MAP_STREAM_CODEC.decode(buffer)
                val cubes = OCube.LIST_STREAM_CODEC.decode(buffer)
                val mesh = ByteBufCodecs.optional(OMesh.STREAM_CODEC).decode(buffer).orElse(null)
                
                return OBone(name, parentName, pivot, rotation, locators, cubes, mesh)
            }
            
            override fun encode(buffer: FriendlyByteBuf, bone: OBone) {
                ByteBufCodecs.STRING_UTF8.encode(buffer, bone.name)
                ByteBufCodecs.optional(ByteBufCodecs.STRING_UTF8).encode(buffer, Optional.ofNullable(bone.parentName))
                SerializeHelper.VEC3_STREAM_CODEC.encode(buffer, bone.pivot)
                SerializeHelper.VEC3_STREAM_CODEC.encode(buffer, bone.rotation)
                OLocator.MAP_STREAM_CODEC.encode(buffer, bone.locators)
                OCube.LIST_STREAM_CODEC.encode(buffer, bone.cubes)
                ByteBufCodecs.optional(OMesh.STREAM_CODEC).encode(buffer, Optional.ofNullable(bone.mesh))
            }
        }

        @JvmStatic
        val MAP_STREAM_CODEC: StreamCodec<FriendlyByteBuf, LinkedHashMap<String, OBone>> = ByteBufCodecs.map(
            ::LinkedHashMap,
            ByteBufCodecs.STRING_UTF8,
            STREAM_CODEC
        )
    }

}