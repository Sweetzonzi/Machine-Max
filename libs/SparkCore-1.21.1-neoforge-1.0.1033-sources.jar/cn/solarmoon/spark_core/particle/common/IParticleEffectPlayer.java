package cn.solarmoon.spark_core.particle.common;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.joml.Quaternionf;

import java.util.UUID;

/**
 * 粒子效果播放器接口（双端共享）。
 * 参考 ISpreadingSoundPlayer 的工厂模式。
 * 方法在 common 包中双端可用，当前仅客户端实际实现。
 * <p>
 * 所有 playEffect 方法返回效果实例的 UUID，可用于后续 {@link #stopEffect} 停止。
 */
public interface IParticleEffectPlayer {

    /**
     * 在指定位置触发粒子效果，无旋转和缩放。
     *
     * @return 效果实例 UUID，可用于停止
     */
    UUID playEffect(Level level, ResourceLocation effectId,
                    Vec3 position);

    /**
     * 在指定位置触发粒子效果，带旋转（四元数）。
     *
     * @return 效果实例 UUID，可用于停止
     */
    UUID playEffect(Level level, ResourceLocation effectId,
                    Vec3 position, Quaternionf rotation);

    /**
     * 在指定位置触发粒子效果，带旋转和非均匀缩放。
     *
     * @return 效果实例 UUID，可用于停止
     */
    UUID playEffect(Level level, ResourceLocation effectId,
                    Vec3 position, Quaternionf rotation, Vec3 scale);

    /**
     * 触发持久粒子效果并绑定到定位器锚点。
     * 发射器每 tick 从 anchor 轮询 locatorName 的实时位姿以跟随移动。
     *
     * @param level       维度
     * @param effectId    粒子效果标识符
     * @param anchor      定位器锚点（位姿轮询源）
     * @param locatorName 定位器名称（如 "muzzle"）
     * @return 效果实例 UUID，可用于停止
     */
    UUID playEffect(Level level, ResourceLocation effectId,
                    IParticleAnchor anchor, String locatorName);

    /**
     * 停止指定粒子的播放（双端可用）。
     *
     * @param level            维度
     * @param effectInstanceId 效果实例 UUID
     */
    void stopEffect(Level level, UUID effectInstanceId);

    /**
     * 动态修改指定发射器实例的运行时贴图。
     * 在发射器存活期间可多次调用切换贴图。
     * 服务端当前为无操作实现。
     *
     * @param level            维度
     * @param effectInstanceId 效果实例 UUID
     * @param texture          新的贴图路径
     */
    void setTexture(Level level, UUID effectInstanceId, ResourceLocation texture);
}
