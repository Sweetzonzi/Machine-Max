package cn.solarmoon.spark_core.test;

import cn.solarmoon.spark_core.physics.test.SparkEntities;
import cn.solarmoon.spark_core.physics.test.TestEntityRenderer;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

@EventBusSubscriber(value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
public class MMRenderHandler {
    @SubscribeEvent//注册每个实体渲染器
    public static void onEntityRendererRegistry(EntityRenderersEvent.RegisterRenderers event){
        event.registerEntityRenderer(SparkEntities.getPART_ENTITY().get(), TestEntityRenderer::new);
    }
}
